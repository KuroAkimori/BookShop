using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace BookStoreApp
{
    public partial class AdminWindow : Window
    {
        private readonly User CurrentUser;
        private readonly bool IsAdmin;
        private List<Book> AllBooks = new List<Book>();
        private List<User> AllUsers = new List<User>();
        private List<Order> AllOrders = new List<Order>();
        private SalesReport LastReport;

        public AdminWindow(User user)
        {
            InitializeComponent();
            CurrentUser = user;
            IsAdmin = user != null && user.IsAdmin;

            ThemeToggle.IsChecked = ThemeManager.IsDark;
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;

            TxtTitle.Text = IsAdmin ? "Панель администратора" : "Панель менеджера";
            TxtSubtitle.Text = string.Format("{0} · {1}", user.UserFullName, user.RoleDisplay);

            if (!IsAdmin)
            {
                TabBooks.Visibility = Visibility.Collapsed;
                TabUsers.Visibility = Visibility.Collapsed;
                Tabs.SelectedItem = TabOrders;
            }

            DpFrom.SelectedDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DpTo.SelectedDate = DateTime.Today;

            if (IsAdmin)
            {
                LoadBooks();
                LoadUsers();
            }
            LoadOrders();
            BuildReport();
        }

        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.ApplyTheme(ThemeToggle.IsChecked == true);
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        #region Каталог

        private void LoadBooks()
        {
            try
            {
                AllBooks = DatabaseHelper.GetAllBooks();
                ApplyBookFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить каталог.\n\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyBookFilter()
        {
            if (GridBooks == null) return;
            string search = TxtBookSearch == null ? string.Empty : TxtBookSearch.Text.Trim().ToLowerInvariant();
            IEnumerable<Book> query = AllBooks;
            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(b => b.SearchString.Contains(search));

            var result = query.OrderBy(b => b.Title).ToList();
            GridBooks.ItemsSource = result;
            TxtBooksCount.Text = string.Format("Показано книг: {0} из {1} · двойной щелчок открывает редактирование",
                result.Count, AllBooks.Count);
        }

        private void BtnAddBook_Click(object sender, RoutedEventArgs e)
        {
            var window = new BookEditWindow { Owner = this };
            if (window.ShowDialog() == true) LoadBooks();
        }

        private void BtnEditBook_Click(object sender, RoutedEventArgs e)
        {
            var book = GridBooks.SelectedItem as Book;
            if (book == null)
            {
                MessageBox.Show("Выберите книгу в таблице.", "Редактирование",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var window = new BookEditWindow(book) { Owner = this };
            if (window.ShowDialog() == true) LoadBooks();
        }

        private void GridBooks_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (GridBooks.SelectedItem is Book) BtnEditBook_Click(sender, e);
        }

        private void BtnDeleteBook_Click(object sender, RoutedEventArgs e)
        {
            var book = GridBooks.SelectedItem as Book;
            if (book == null)
            {
                MessageBox.Show("Выберите книгу в таблице.", "Удаление",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (MessageBox.Show(string.Format("Удалить книгу «{0}»?\n\nДействие нельзя отменить.", book.Title),
                    "Удаление книги", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            string error;
            if (DatabaseHelper.TryDeleteBook(book.BookID, out error))
            {
                LoadBooks();
            }
            else
            {
                MessageBox.Show(error, "Удаление книги", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnRefreshBooks_Click(object sender, RoutedEventArgs e) { LoadBooks(); }

        private void TxtBookSearch_TextChanged(object sender, TextChangedEventArgs e) { ApplyBookFilter(); }

        #endregion

        #region Пользователи

        private void LoadUsers()
        {
            try
            {
                AllUsers = DatabaseHelper.GetAllUsers();
                ApplyUserFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить пользователей.\n\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyUserFilter()
        {
            if (GridUsers == null) return;
            string search = TxtUserSearch == null ? string.Empty : TxtUserSearch.Text.Trim().ToLowerInvariant();
            IEnumerable<User> query = AllUsers;
            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(u =>
                    (u.UserLogin ?? string.Empty).ToLowerInvariant().Contains(search) ||
                    (u.UserFullName ?? string.Empty).ToLowerInvariant().Contains(search) ||
                    (u.ContactDisplay ?? string.Empty).ToLowerInvariant().Contains(search));
            }

            var result = query.OrderBy(u => u.RoleID).ThenBy(u => u.UserLogin).ToList();
            GridUsers.ItemsSource = result;
            TxtUsersCount.Text = string.Format("Показано пользователей: {0} из {1}", result.Count, AllUsers.Count);
        }

        private void BtnBlockUser_Click(object sender, RoutedEventArgs e)
        {
            var user = GridUsers.SelectedItem as User;
            if (user == null) { MessageBox.Show("Выберите пользователя.", "Блокировка", MessageBoxButton.OK, MessageBoxImage.Information); return; }
            if (user.UserID == CurrentUser.UserID) { MessageBox.Show("Нельзя заблокировать собственную учётную запись.", "Блокировка", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            if (user.IsBlocked) { MessageBox.Show("Пользователь уже заблокирован.", "Блокировка", MessageBoxButton.OK, MessageBoxImage.Information); return; }

            if (MessageBox.Show(string.Format("Заблокировать пользователя «{0}»?", user.UserLogin),
                    "Блокировка", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

            try { DatabaseHelper.SetUserBlocked(user.UserID, true); LoadUsers(); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Блокировка", MessageBoxButton.OK, MessageBoxImage.Warning); }
        }

        private void BtnUnblockUser_Click(object sender, RoutedEventArgs e)
        {
            var user = GridUsers.SelectedItem as User;
            if (user == null) { MessageBox.Show("Выберите пользователя.", "Разблокировка", MessageBoxButton.OK, MessageBoxImage.Information); return; }
            if (!user.IsBlocked) { MessageBox.Show("Пользователь не заблокирован.", "Разблокировка", MessageBoxButton.OK, MessageBoxImage.Information); return; }

            try { DatabaseHelper.SetUserBlocked(user.UserID, false); LoadUsers(); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Разблокировка", MessageBoxButton.OK, MessageBoxImage.Warning); }
        }

        private void BtnResetPassword_Click(object sender, RoutedEventArgs e)
        {
            var user = GridUsers.SelectedItem as User;
            if (user == null) { MessageBox.Show("Выберите пользователя.", "Сброс пароля", MessageBoxButton.OK, MessageBoxImage.Information); return; }

            if (MessageBox.Show(string.Format("Сбросить пароль пользователя «{0}»?\n\nБудет сгенерирован временный пароль.", user.UserLogin),
                    "Сброс пароля", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

            string newPassword = Guid.NewGuid().ToString("N").Substring(0, 8);
            try
            {
                DatabaseHelper.ResetUserPassword(user.UserID, newPassword);
                try { Clipboard.SetText(newPassword); } catch { }
                MessageBox.Show(string.Format("Пароль пользователя «{0}» изменён.\n\nВременный пароль: {1}\n\nПароль скопирован в буфер обмена.",
                    user.UserLogin, newPassword), "Сброс пароля", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Сброс пароля", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnRefreshUsers_Click(object sender, RoutedEventArgs e) { LoadUsers(); }

        private void TxtUserSearch_TextChanged(object sender, TextChangedEventArgs e) { ApplyUserFilter(); }

        #endregion

        #region Заказы

        private void LoadOrders()
        {
            try
            {
                DatabaseHelper.SimulateStatusChanges();
                AllOrders = DatabaseHelper.GetAllOrders();
                ApplyOrderFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить заказы.\n\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyOrderFilter()
        {
            if (GridAdminOrders == null) return;
            string search = TxtAdminOrderSearch == null ? string.Empty : TxtAdminOrderSearch.Text.Trim().ToLowerInvariant();
            IEnumerable<Order> query = AllOrders;

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(o =>
                    o.OrderID.ToString().Contains(search) ||
                    (o.UserLogin ?? string.Empty).ToLowerInvariant().Contains(search) ||
                    (o.UserFullName ?? string.Empty).ToLowerInvariant().Contains(search));
            }

            var statusItem = CmbAdminStatusFilter == null ? null : CmbAdminStatusFilter.SelectedItem as ComboBoxItem;
            string status = statusItem == null ? string.Empty : (statusItem.Tag as string ?? string.Empty);
            if (!string.IsNullOrWhiteSpace(status))
                query = query.Where(o => o.Status == status);

            var result = query.ToList();
            GridAdminOrders.ItemsSource = result;

            if (result.Count > 0)
            {
                if (GridAdminOrders.SelectedItem == null || !result.Contains((Order)GridAdminOrders.SelectedItem))
                    GridAdminOrders.SelectedIndex = 0;
            }
            else
            {
                ShowOrderDetails(null);
            }
        }

        private void ShowOrderDetails(Order order)
        {
            if (order == null)
            {
                TxtAdminOrderSummary.Text = "Выберите заказ";
                TxtAdminOrderHint.Text = "Состав заказа появится справа";
                LstAdminOrderItems.ItemsSource = null;
                return;
            }

            TxtAdminOrderSummary.Text = string.Format("{0} · {1}\n{2} ({3})",
                order.OrderNumber, order.DateDisplay, order.UserFullName, order.UserLogin);
            TxtAdminOrderHint.Text = string.Format("Статус: {0} · {1} · итого {2:N2} ₽",
                order.Status, order.ItemsCountDisplay, order.TotalAmount);
            LstAdminOrderItems.ItemsSource = order.Items;
        }

        private void GridAdminOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ShowOrderDetails(GridAdminOrders.SelectedItem as Order);
        }

        private void GridAdminOrders_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (GridAdminOrders.SelectedItem is Order) OpenReceipt((Order)GridAdminOrders.SelectedItem);
        }

        private void BtnApplyStatus_Click(object sender, RoutedEventArgs e)
        {
            var order = GridAdminOrders.SelectedItem as Order;
            if (order == null) { MessageBox.Show("Выберите заказ.", "Статус заказа", MessageBoxButton.OK, MessageBoxImage.Information); return; }

            var item = CmbNewStatus.SelectedItem as ComboBoxItem;
            string newStatus = item == null ? null : item.Tag as string;
            if (string.IsNullOrWhiteSpace(newStatus)) return;

            if (order.Status == newStatus)
            {
                MessageBox.Show("Заказ уже имеет этот статус.", "Статус заказа", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (newStatus == "Отменён" &&
                MessageBox.Show(string.Format("Отменить заказ {0}? Книги вернутся на склад.", order.OrderNumber),
                    "Отмена заказа", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

            try
            {
                DatabaseHelper.UpdateOrderStatus(order.OrderID, newStatus, newStatus == "Отменён");
                LoadOrders();
                if (IsAdmin) LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Статус заказа", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnAdminCancelOrder_Click(object sender, RoutedEventArgs e)
        {
            var order = GridAdminOrders.SelectedItem as Order;
            if (order == null) { MessageBox.Show("Выберите заказ.", "Отмена заказа", MessageBoxButton.OK, MessageBoxImage.Information); return; }
            if (!order.CanCancel)
            {
                MessageBox.Show("Этот заказ уже выполнен или отменён.", "Отмена заказа",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (MessageBox.Show(string.Format("Отменить заказ {0} на сумму {1:N2} ₽?\n\nКниги вернутся на склад.",
                    order.OrderNumber, order.TotalAmount), "Отмена заказа",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

            try
            {
                DatabaseHelper.UpdateOrderStatus(order.OrderID, "Отменён", true);
                LoadOrders();
                if (IsAdmin) LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Отмена заказа", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnAdminOrderReceipt_Click(object sender, RoutedEventArgs e)
        {
            var order = GridAdminOrders.SelectedItem as Order;
            if (order == null) { MessageBox.Show("Выберите заказ.", "Чек", MessageBoxButton.OK, MessageBoxImage.Information); return; }
            OpenReceipt(order);
        }

        private void OpenReceipt(Order order)
        {
            var receipt = new ReceiptWindow(order) { Owner = this };
            receipt.ShowDialog();
        }

        private void BtnRefreshOrders_Click(object sender, RoutedEventArgs e) { LoadOrders(); }

        private void TxtAdminOrderSearch_TextChanged(object sender, TextChangedEventArgs e) { ApplyOrderFilter(); }

        private void CmbAdminStatusFilter_SelectionChanged(object sender, SelectionChangedEventArgs e) { ApplyOrderFilter(); }

        #endregion

        #region Отчёты

        private void BuildReport()
        {
            if (DpFrom == null || DpTo == null) return;
            if (!DpFrom.SelectedDate.HasValue || !DpTo.SelectedDate.HasValue)
            {
                MessageBox.Show("Укажите начало и конец периода.", "Отчёт",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            DateTime from = DpFrom.SelectedDate.Value.Date;
            DateTime to = DpTo.SelectedDate.Value.Date;
            if (from > to)
            {
                MessageBox.Show("Начало периода не может быть позже окончания.", "Отчёт",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                LastReport = DatabaseHelper.GetSalesReport(from, to);
                TxtReportOrders.Text = LastReport.OrdersCount.ToString();
                TxtReportRevenue.Text = string.Format("{0:N2} ₽", LastReport.Revenue);
                TxtReportAverage.Text = string.Format("{0:N2} ₽", LastReport.AverageOrder);
                TxtReportBooks.Text = LastReport.BooksSold.ToString();
                GridTopBooks.ItemsSource = LastReport.TopBooks;
                TxtReportSummary.Text = string.Format("Период: {0:dd.MM.yyyy} — {1:dd.MM.yyyy}. Учтены все заказы, кроме отменённых.",
                    from, to);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось построить отчёт.\n\n" + ex.Message,
                    "Отчёт", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnBuildReport_Click(object sender, RoutedEventArgs e) { BuildReport(); }

        private void BtnExportReport_Click(object sender, RoutedEventArgs e)
        {
            if (LastReport == null) BuildReport();
            if (LastReport == null) return;

            var dialog = new SaveFileDialog
            {
                Filter = "CSV-файл (*.csv)|*.csv",
                FileName = string.Format("sales_report_{0:yyyyMMdd}.csv", DateTime.Today)
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("Отчёт по продажам BookStore");
                sb.AppendLine(string.Format("Период;{0:dd.MM.yyyy};{1:dd.MM.yyyy}", LastReport.DateFrom, LastReport.DateTo));
                sb.AppendLine(string.Format("Заказов;{0}", LastReport.OrdersCount));
                sb.AppendLine(string.Format("Выручка;{0:N2}", LastReport.Revenue));
                sb.AppendLine(string.Format("Средний чек;{0:N2}", LastReport.AverageOrder));
                sb.AppendLine(string.Format("Продано книг;{0}", LastReport.BooksSold));
                sb.AppendLine();
                sb.AppendLine("Книга;Автор;Количество;Выручка");
                foreach (var row in LastReport.TopBooks)
                {
                    sb.AppendLine(string.Format("{0};{1};{2};{3:N2}",
                        EscapeCsv(row.Title), EscapeCsv(row.Author), row.Quantity, row.Revenue));
                }

                File.WriteAllText(dialog.FileName, sb.ToString(), new UTF8Encoding(true));
                MessageBox.Show("Отчёт сохранён:\n" + dialog.FileName, "Экспорт",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить отчёт.\n\n" + ex.Message,
                    "Экспорт", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static string EscapeCsv(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            if (value.Contains(";") || value.Contains("\""))
                return "\"" + value.Replace("\"", "\"\"") + "\"";
            return value;
        }

        #endregion

        private void BtnClose_Click(object sender, RoutedEventArgs e) { Close(); }
    }
}
