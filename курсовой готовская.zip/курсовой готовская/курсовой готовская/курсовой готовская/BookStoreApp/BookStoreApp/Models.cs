﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BookStoreApp
{
    /// <summary>Идентификаторы ролей, используемые в базе данных.</summary>
    public static class RoleIds
    {
        public const int Admin = 1;
        public const int Client = 2;
        public const int Manager = 3;
    }

    public class User
    {
        public int UserID { get; set; }
        public string UserLogin { get; set; }
        public string UserFullName { get; set; }
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public bool IsBlocked { get; set; }
        public int FailedAttempts { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }

        public bool IsAdmin { get { return RoleID == RoleIds.Admin; } }
        public bool IsManager { get { return RoleID == RoleIds.Manager; } }
        public bool IsClient { get { return RoleID == RoleIds.Client; } }
        public bool CanManageOrders { get { return IsAdmin || IsManager; } }
        public string RoleDisplay
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(RoleName)) return RoleName;
                if (IsAdmin) return "Администратор";
                if (IsManager) return "Менеджер";
                return "Клиент";
            }
        }
        public string Initials
        {
            get
            {
                if (string.IsNullOrWhiteSpace(UserFullName)) return "?";
                var parts = UserFullName.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2) return (parts[0][0].ToString() + parts[1][0].ToString()).ToUpper();
                return parts[0][0].ToString().ToUpper();
            }
        }
        public string ContactDisplay
        {
            get
            {
                var parts = new List<string>();
                if (!string.IsNullOrWhiteSpace(Email)) parts.Add(Email);
                if (!string.IsNullOrWhiteSpace(Phone)) parts.Add(Phone);
                return parts.Count == 0 ? "—" : string.Join(" · ", parts);
            }
        }
        public string BlockedDisplay { get { return IsBlocked ? "Заблокирован" : "Активен"; } }
        public bool IsActive { get { return !IsBlocked; } }
    }

    public class Book
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int PublisherID { get; set; }
        public string PublisherName { get; set; }
        public string Genre { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public string CoverImagePath { get; set; }
        public string ISBN { get; set; }
        public int? YearPublished { get; set; }
        public string Description { get; set; }
        public string PublisherContactPerson { get; set; }
        public string PublisherPhone { get; set; }

        public bool InStock { get { return StockQuantity > 0; } }
        public string SearchString
        {
            get
            {
                return string.Format("{0} {1} {2} {3} {4}", Title, Author, Genre, PublisherName, ISBN)
                    .ToLowerInvariant();
            }
        }
        public string YearDisplay { get { return YearPublished.HasValue ? YearPublished.Value.ToString() : "—"; } }
        public string StockDisplay
        {
            get { return StockQuantity > 0 ? string.Format("В наличии: {0} шт.", StockQuantity) : "Нет в наличии"; }
        }
        public string PublisherAndYear
        {
            get
            {
                if (string.IsNullOrWhiteSpace(PublisherName)) return YearDisplay;
                return YearPublished.HasValue
                    ? string.Format("{0}, {1}", PublisherName, YearPublished.Value)
                    : PublisherName;
            }
        }
        public string CoverFullPath
        {
            get { return CoverStorage.Resolve(CoverImagePath); }
        }
        public bool HasCover
        {
            get { return File.Exists(CoverFullPath); }
        }
    }

    public class Publisher
    {
        public int PublisherID { get; set; }
        public string PublisherName { get; set; }
        public string ContactPerson { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }

        public override string ToString() { return PublisherName; }
    }

    public class CartItem
    {
        public int CartItemID { get; set; }
        public int UserID { get; set; }
        public Book Book { get; set; }
        public int Quantity { get; set; }
        public decimal Total { get { return Book == null ? 0 : Book.Price * Quantity; } }
        public string QuantityDisplay { get { return Quantity + " шт."; } }
        public bool CanIncrease { get { return Book != null && Quantity < Book.StockQuantity; } }
        public bool CanDecrease { get { return Quantity > 1; } }
    }

    public class OrderItem
    {
        public int OrderItemID { get; set; }
        public int OrderID { get; set; }
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int Quantity { get; set; }
        public decimal PriceAtPurchase { get; set; }
        public decimal Total { get { return PriceAtPurchase * Quantity; } }
        public string Summary
        {
            get { return string.Format("{0} — {1} шт. × {2:N2} ₽ = {3:N2} ₽", Title, Quantity, PriceAtPurchase, Total); }
        }
    }

    public class Order
    {
        public int OrderID { get; set; }
        public int UserID { get; set; }
        public string UserLogin { get; set; }
        public string UserFullName { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime? CreatedAt { get; set; }
        public string Status { get; set; }
        public decimal TotalAmount { get; set; }
        public List<OrderItem> Items { get; set; }

        public Order()
        {
            Items = new List<OrderItem>();
        }

        public string OrderNumber { get { return string.Format("№ {0}", OrderID); } }
        public string DateDisplay { get { return OrderDate.ToString("dd.MM.yyyy HH:mm"); } }
        public string ItemsCountDisplay
        {
            get
            {
                int count = Items == null ? 0 : Items.Sum(i => i.Quantity);
                return string.Format("{0} поз. / {1} шт.", Items == null ? 0 : Items.Count, count);
            }
        }
        public bool CanCancel
        {
            get { return Status == "В обработке" || Status == "Собирается"; }
        }
        public string ItemsSummary
        {
            get
            {
                if (Items == null || Items.Count == 0) return "Состав заказа не загружен";
                return string.Join("\n", Items.Select(i => i.Summary));
            }
        }
    }

    public class SalesReport
    {
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public int OrdersCount { get; set; }
        public decimal Revenue { get; set; }
        public decimal AverageOrder { get; set; }
        public int BooksSold { get; set; }
        public List<TopBookRow> TopBooks { get; set; }

        public SalesReport()
        {
            TopBooks = new List<TopBookRow>();
        }
    }

    public class TopBookRow
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int Quantity { get; set; }
        public decimal Revenue { get; set; }
    }
}
