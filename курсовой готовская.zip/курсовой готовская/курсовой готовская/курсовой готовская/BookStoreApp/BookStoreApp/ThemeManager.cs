﻿using System;
using System.Linq;
using System.Windows;

namespace BookStoreApp
{
    public static class ThemeManager
    {
        public static bool IsDark { get; private set; }

        public static void ApplyTheme(bool isDark)
        {
            IsDark = isDark;
            var dictionaries = Application.Current.Resources.MergedDictionaries;
            var currentTheme = dictionaries.FirstOrDefault(d => d.Source != null &&
                (d.Source.OriginalString.Contains("LightTheme.xaml") || d.Source.OriginalString.Contains("DarkTheme.xaml")));

            if (currentTheme != null)
            {
                dictionaries.Remove(currentTheme);
            }

            string themePath = isDark ? "Themes/DarkTheme.xaml" : "Themes/LightTheme.xaml";
            var newTheme = new ResourceDictionary { Source = new Uri(themePath, UriKind.Relative) };
            dictionaries.Add(newTheme);
        }

        public static void Toggle()
        {
            ApplyTheme(!IsDark);
        }

        public static string IconForCurrentTheme
        {
            get { return IsDark ? "☀️" : "🌙"; }
        }
    }
}
