using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BookStoreApp
{
    public partial class OrdersWindow : Window
    {
        private readonly User CurrentUser;
        private List<Order> AllOrders = new List<Order>();

        public OrdersWindow(User user)
        {
            InitializeComponent();
            CurrentUser = user;
            ThemeToggle.IsChecked = ThemeManager.IsDark;
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
            LoadOrders();
        }

        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.ApplyTheme(ThemeToggle.IsChecked == true);
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        private void LoadOrders()
        {
            try
            {
                DatabaseHelper.SimulateStatusChanges();
                AllOrders = DatabaseHelper.GetOrdersByUser(CurrentUser.UserID);
                ApplyFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить заказы.\n\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            if (GridOrders == null) return;

            IEnumerable<Order> query = AllOrders;
            string search = TxtSearch == null ? string.Empty : TxtSearch.Text.Trim();

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(o =>
                    o.OrderID.ToString().Contains(search) ||
                    o.DateDisplay.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    o.TotalAmount.ToString("N2").Contains(search));
            }

            var statusItem = CmbStatus == null ? null : CmbStatus.SelectedItem as ComboBoxItem;
            string status = statusItem == null ? string.Empty : (statusItem.Tag as string ?? string.Empty);
            if (!string.IsNullOrWhiteSpace(status))
                query = query.Where(o => o.Status == status);

            var result = query.ToList();
            GridOrders.ItemsSource = result;
            TxtCount.Text = string.Format("Найдено заказов: {0}", result.Count);

            if (result.Count > 0)
            {
                if (GridOrders.SelectedItem == null || !result.Contains((Order)GridOrders.SelectedItem))
                    GridOrders.SelectedIndex = 0;
            }
            else
            {
                ShowDetails(null);
            }
        }

        private void ShowDetails(Order order)
        {
            if (order == null)
            {
                TxtDetailsTitle.Text = "Выберите заказ";
                TxtDetailsMeta.Text = "Сведения о заказе появятся здесь";
                LstDetailsItems.ItemsSource = null;
                TxtDetailsTotal.Text = "—";
                BtnReceipt.IsEnabled = false;
                BtnCancelOrder.IsEnabled = false;
                return;
            }

            TxtDetailsTitle.Text = "Заказ " + order.OrderNumber;
            TxtDetailsMeta.Text = string.Format("{0}\nСтатус: {1} · {2}",
                order.DateDisplay, order.Status, order.ItemsCountDisplay);
            LstDetailsItems.ItemsSource = order.Items;
            TxtDetailsTotal.Text = string.Format("{0:N2} ₽", order.TotalAmount);
            BtnReceipt.IsEnabled = true;
            BtnCancelOrder.IsEnabled = order.CanCancel;
        }

        private void GridOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ShowDetails(GridOrders.SelectedItem as Order);
        }

        private void GridOrders_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var order = GridOrders.SelectedItem as Order;
            if (order != null) OpenReceipt(order);
        }

        private void BtnReceipt_Click(object sender, RoutedEventArgs e)
        {
            var order = GridOrders.SelectedItem as Order;
            if (order == null)
            {
                MessageBox.Show("Выберите заказ в списке.", "Чек", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            OpenReceipt(order);
        }

        private void OpenReceipt(Order order)
        {
            var receipt = new ReceiptWindow(order) { Owner = this };
            receipt.ShowDialog();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            var order = GridOrders.SelectedItem as Order;
            if (order == null) return;

            if (!order.CanCancel)
            {
                MessageBox.Show("Этот заказ уже выполнен или отменён.", "Отмена заказа",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (MessageBox.Show(string.Format("Отменить заказ {0} на сумму {1:N2} ₽?\n\nКниги вернутся на склад.",
                    order.OrderNumber, order.TotalAmount), "Отмена заказа",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

            try
            {
                DatabaseHelper.CancelOrder(order.OrderID, CurrentUser.UserID, false);
                MessageBox.Show("Заказ отменён, товары возвращены на склад.", "Готово",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                LoadOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Отмена заказа", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) { ApplyFilter(); }

        private void CmbStatus_SelectionChanged(object sender, SelectionChangedEventArgs e) { ApplyFilter(); }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) { LoadOrders(); }

        private void BtnBack_Click(object sender, RoutedEventArgs e) { Close(); }
    }
}
