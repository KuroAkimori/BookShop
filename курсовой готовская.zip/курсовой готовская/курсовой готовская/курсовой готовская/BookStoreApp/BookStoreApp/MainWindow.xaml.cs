﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace BookStoreApp
{
    public partial class MainWindow : Window
    {
        private readonly User CurrentUser;
        private List<Book> AllBooks = new List<Book>();
        private bool filtersLoaded;
        private DispatcherTimer toastTimer;

        public MainWindow(User user)
        {
            InitializeComponent();
            CurrentUser = user;

            ThemeToggle.IsChecked = ThemeManager.IsDark;
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;

            if (CurrentUser != null)
            {
                TxtUserInfo.Text = CurrentUser.UserFullName;
                TxtInitials.Text = CurrentUser.Initials;
                TxtRole.Text = CurrentUser.RoleDisplay;
                BtnCart.Visibility = Visibility.Visible;
                BtnOrders.Visibility = CurrentUser.IsClient ? Visibility.Visible : Visibility.Collapsed;
                BtnAdminPanel.Visibility = CurrentUser.CanManageOrders ? Visibility.Visible : Visibility.Collapsed;
                BtnAdminPanel.Content = CurrentUser.IsAdmin ? "⚙ Панель администратора" : "⚙ Панель менеджера";
            }
            else
            {
                TxtUserInfo.Text = "Гость";
                TxtInitials.Text = "Г";
                TxtRole.Text = "гостевой режим";
                BtnCart.Visibility = Visibility.Collapsed;
                BtnOrders.Visibility = Visibility.Collapsed;
                BtnAdminPanel.Visibility = Visibility.Collapsed;
            }

            LoadData();
        }

        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.ApplyTheme(ThemeToggle.IsChecked == true);
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        private void LoadData()
        {
            try
            {
                AllBooks = DatabaseHelper.GetAllBooks();
                if (!filtersLoaded)
                {
                    LoadFilters();
                    filtersLoaded = true;
                }
                FilterBooks();
                UpdateCartBadge();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить каталог.\n\n" + ex.Message,
                    "Ошибка подключения", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadFilters()
        {
            var publishers = DatabaseHelper.GetAllPublishers();
            CmbPublisher.Items.Clear();
            CmbPublisher.Items.Add(new ComboBoxItem { Content = "Все издательства", Tag = 0 });
            foreach (var p in publishers)
                CmbPublisher.Items.Add(new ComboBoxItem { Content = p.PublisherName, Tag = p.PublisherID });
            CmbPublisher.SelectedIndex = 0;

            var genres = DatabaseHelper.GetAllGenres();
            CmbGenre.Items.Clear();
            CmbGenre.Items.Add(new ComboBoxItem { Content = "Все жанры", Tag = string.Empty });
            foreach (var genre in genres)
                CmbGenre.Items.Add(new ComboBoxItem { Content = genre, Tag = genre });
            CmbGenre.SelectedIndex = 0;
        }

        private void FilterBooks()
        {
            if (IcBooks == null || TxtCounter == null) return;

            IEnumerable<Book> query = AllBooks;
            string search = TxtSearch == null ? string.Empty : TxtSearch.Text.Trim().ToLowerInvariant();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(b => b.SearchString.Contains(search));

            var publisherItem = CmbPublisher == null ? null : CmbPublisher.SelectedItem as ComboBoxItem;
            if (publisherItem != null && publisherItem.Tag is int && (int)publisherItem.Tag > 0)
            {
                int publisherId = (int)publisherItem.Tag;
                query = query.Where(b => b.PublisherID == publisherId);
            }

            var genreItem = CmbGenre == null ? null : CmbGenre.SelectedItem as ComboBoxItem;
            if (genreItem != null && genreItem.Tag is string && !string.IsNullOrWhiteSpace((string)genreItem.Tag))
            {
                string genre = (string)genreItem.Tag;
                query = query.Where(b => b.Genre == genre);
            }

            int sortIndex = CmbSort == null ? 0 : CmbSort.SelectedIndex;
            switch (sortIndex)
            {
                case 1: query = query.OrderBy(b => b.Price); break;
                case 2: query = query.OrderByDescending(b => b.Price); break;
                case 3: query = query.OrderByDescending(b => b.InStock).ThenBy(b => b.Title); break;
                default: query = query.OrderBy(b => b.Title); break;
            }

            var result = query.ToList();
            IcBooks.ItemsSource = result;
            TxtCounter.Text = string.Format("Показано книг: {0} из {1}", result.Count, AllBooks.Count);
            EmptyState.Visibility = result.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) { FilterBooks(); }
        private void CmbPublisher_SelectionChanged(object sender, SelectionChangedEventArgs e) { FilterBooks(); }
        private void CmbGenre_SelectionChanged(object sender, SelectionChangedEventArgs e) { FilterBooks(); }
        private void CmbSort_SelectionChanged(object sender, SelectionChangedEventArgs e) { FilterBooks(); }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            TxtSearch.Text = string.Empty;
            if (CmbPublisher.Items.Count > 0) CmbPublisher.SelectedIndex = 0;
            if (CmbGenre.Items.Count > 0) CmbGenre.SelectedIndex = 0;
            if (CmbSort.Items.Count > 0) CmbSort.SelectedIndex = 0;
            FilterBooks();
        }

        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentUser == null)
            {
                MessageBox.Show("Чтобы добавлять книги в корзину, войдите в личный кабинет или зарегистрируйтесь.",
                    "Требуется авторизация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var button = sender as Button;
            var book = button == null ? null : button.Tag as Book;
            if (book == null) return;

            try
            {
                int count = DatabaseHelper.AddToCart(CurrentUser.UserID, book.BookID, 1);
                UpdateCartBadge(count);
                ShowToast(string.Format("«{0}» добавлена в корзину", book.Title));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Корзина", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void UpdateCartBadge(int? knownCount = null)
        {
            if (CurrentUser == null)
            {
                CartBadge.Visibility = Visibility.Collapsed;
                return;
            }
            try
            {
                int count = knownCount.HasValue ? knownCount.Value : DatabaseHelper.GetCartCount(CurrentUser.UserID);
                TxtCartCount.Text = count.ToString();
                CartBadge.Visibility = count > 0 ? Visibility.Visible : Visibility.Collapsed;
            }
            catch
            {
                CartBadge.Visibility = Visibility.Collapsed;
            }
        }

        private void ShowToast(string message)
        {
            TxtToast.Text = message;
            Toast.Visibility = Visibility.Visible;
            if (toastTimer != null) toastTimer.Stop();
            toastTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2.5) };
            toastTimer.Tick += (s, args) =>
            {
                Toast.Visibility = Visibility.Collapsed;
                toastTimer.Stop();
            };
            toastTimer.Start();
        }

        private void BtnCart_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentUser == null)
            {
                MessageBox.Show("Корзина доступна только авторизованным пользователям.",
                    "Требуется авторизация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var window = new CartWindow(CurrentUser) { Owner = this };
            window.ShowDialog();
            LoadData();
        }

        private void BtnOrders_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentUser == null)
            {
                MessageBox.Show("История заказов доступна только авторизованным пользователям.",
                    "Требуется авторизация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var window = new OrdersWindow(CurrentUser) { Owner = this };
            window.ShowDialog();
            LoadData();
        }

        private void BtnAdminPanel_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentUser == null || !CurrentUser.CanManageOrders) return;
            var window = new AdminWindow(CurrentUser) { Owner = this };
            window.ShowDialog();
            LoadData();
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new LoginWindow();
            Application.Current.MainWindow = loginWindow;
            loginWindow.Show();
            Close();
        }
    }
}
