using System;
using System.Windows;
using System.Windows.Controls;

namespace BookStoreApp
{
    public partial class ReceiptWindow : Window
    {
        private readonly Order CurrentOrder;

        public ReceiptWindow(Order order)
        {
            InitializeComponent();
            CurrentOrder = order;
            ShowReceipt();
        }

        private void ShowReceipt()
        {
            if (CurrentOrder == null) return;

            TxtOrderNumber.Text = "Заказ " + CurrentOrder.OrderNumber;
            TxtOrderDate.Text = CurrentOrder.DateDisplay;
            TxtCustomer.Text = string.IsNullOrWhiteSpace(CurrentOrder.UserFullName)
                ? CurrentOrder.UserLogin
                : CurrentOrder.UserFullName;
            IcItems.ItemsSource = CurrentOrder.Items;
            TxtTotal.Text = string.Format("{0:N2} ₽", CurrentOrder.TotalAmount);
            TxtStatus.Text = "Статус заказа: " + CurrentOrder.Status;
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() != true) return;

            try
            {
                ReceiptPanel.UpdateLayout();
                dialog.PrintVisual(ReceiptPanel, "Чек BookStore " + CurrentOrder.OrderNumber);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось отправить документ на печать.\n\n" + ex.Message,
                    "Печать", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
