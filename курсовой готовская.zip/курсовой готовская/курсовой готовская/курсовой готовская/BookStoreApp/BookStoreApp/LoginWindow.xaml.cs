﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;

namespace BookStoreApp
{
    public partial class LoginWindow : Window
    {
        private bool isCaptchaRequired;
        private DispatcherTimer cooldownTimer;

        public LoginWindow()
        {
            InitializeComponent();
            ThemeToggle.IsChecked = ThemeManager.IsDark;
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.ApplyTheme(ThemeToggle.IsChecked == true);
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            TxtError.Text = string.Empty;
            string login = TxtLogin.Text.Trim();
            string password = TxtPassword.Password;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                TxtError.Text = "Заполните логин и пароль.";
                return;
            }

            if (isCaptchaRequired &&
                !string.Equals(TxtCaptcha.Text.Trim(), Captcha.CurrentText, StringComparison.OrdinalIgnoreCase))
            {
                TxtError.Text = "Неверный код с картинки.";
                ImgCaptcha.Source = Captcha.GenerateImage();
                TxtCaptcha.Clear();
                return;
            }

            try
            {
                var user = DatabaseHelper.Authenticate(login, password);

                if (user == null)
                {
                    DatabaseHelper.UpdateLoginAttempts(login, false);
                    var checkUser = DatabaseHelper.AuthenticateByLogin(login);
                    int attempts = checkUser == null ? 0 : checkUser.FailedAttempts;

                    TxtError.Text = "Неверный логин или пароль.";

                    if (attempts >= 3 && !isCaptchaRequired)
                    {
                        isCaptchaRequired = true;
                        CaptchaPanel.Visibility = Visibility.Visible;
                        ImgCaptcha.Source = Captcha.GenerateImage();
                        TxtCaptcha.Clear();
                        TxtError.Text = string.Format("Неверный логин или пароль. Введите код с картинки (ошибок: {0}).", attempts);
                    }

                    if (attempts >= 5)
                        StartCooldown();
                    return;
                }

                if (user.IsBlocked)
                {
                    TxtError.Text = "Учётная запись заблокирована. Обратитесь к администратору.";
                    return;
                }

                DatabaseHelper.UpdateLoginAttempts(login, true);

                var mainWindow = new MainWindow(user);
                Application.Current.MainWindow = mainWindow;
                mainWindow.Show();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при входе:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StartCooldown()
        {
            if (cooldownTimer != null) cooldownTimer.Stop();
            BtnLogin.IsEnabled = false;
            TxtError.Text = "Слишком много неудачных попыток. Подождите 10 секунд.";
            cooldownTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
            cooldownTimer.Tick += (s, args) =>
            {
                BtnLogin.IsEnabled = true;
                TxtError.Text = string.Empty;
                cooldownTimer.Stop();
            };
            cooldownTimer.Start();
        }

        private void BtnGuest_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow(null);
            Application.Current.MainWindow = mainWindow;
            mainWindow.Show();
            Close();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            var regWindow = new RegisterWindow { Owner = this };
            if (regWindow.ShowDialog() == true && !string.IsNullOrWhiteSpace(regWindow.RegisteredLogin))
            {
                TxtLogin.Text = regWindow.RegisteredLogin;
                TxtPassword.Focus();
                TxtError.Text = string.Empty;
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && BtnLogin.IsEnabled)
                BtnLogin_Click(sender, e);
        }
    }
}
