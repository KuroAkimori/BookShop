﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace BookStoreApp
{
    /// <summary>
    /// Слой доступа к данным. Все запросы параметризованы, что исключает SQL-инъекции.
    /// </summary>
    public static class DatabaseHelper
    {
        private const string FallbackConnectionString =
            @"Server=stud-mssql.sttec.yar.ru,38325;Database=user83_db;User Id=user83_db;Password=user83;TrustServerCertificate=True;";

        private static string ConnString
        {
            get
            {
                var setting = ConfigurationManager.ConnectionStrings["BookStoreDb"];
                return setting != null && !string.IsNullOrWhiteSpace(setting.ConnectionString)
                    ? setting.ConnectionString
                    : FallbackConnectionString;
            }
        }

        #region Безопасность и пользователи

        public static string ComputeSha256(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input ?? string.Empty));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static User Authenticate(string login, string password)
        {
            string hashedPassword = ComputeSha256(password).ToLowerInvariant().Trim();
            const string query = @"
                SELECT u.UserID, u.UserLogin, u.UserPassword, u.UserFullName, u.RoleID, r.RoleName,
                       u.IsBlocked, u.FailedAttempts, u.Phone, u.Email, u.Address
                FROM UsersBS u
                JOIN RolesBS r ON r.RoleID = u.RoleID
                WHERE LTRIM(RTRIM(u.UserLogin)) = LTRIM(RTRIM(@login));";

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login ?? string.Empty);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string dbHash = reader["UserPassword"].ToString().Trim().ToLowerInvariant();
                            if (string.Equals(dbHash, hashedPassword, StringComparison.Ordinal))
                            {
                                return MapUser(reader);
                            }
                        }
                    }
                }
            }
            return null;
        }

        public static User AuthenticateByLogin(string login)
        {
            const string query = @"
                SELECT u.UserID, u.UserLogin, u.UserFullName, u.RoleID, r.RoleName,
                       u.IsBlocked, u.FailedAttempts, u.Phone, u.Email, u.Address
                FROM UsersBS u
                JOIN RolesBS r ON r.RoleID = u.RoleID
                WHERE LOWER(LTRIM(RTRIM(u.UserLogin))) = LOWER(LTRIM(RTRIM(@login)));";

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login ?? string.Empty);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) return MapUser(reader);
                    }
                }
            }
            return null;
        }

        public static bool LoginExists(string login)
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT COUNT(*) FROM UsersBS WHERE LOWER(UserLogin) = LOWER(@login)", conn))
                {
                    cmd.Parameters.AddWithValue("@login", login ?? string.Empty);
                    return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                }
            }
        }

        public static void UpdateLoginAttempts(string login, bool isSuccess)
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                string query = isSuccess
                    ? "UPDATE UsersBS SET FailedAttempts = 0 WHERE LTRIM(RTRIM(UserLogin)) = LTRIM(RTRIM(@login))"
                    : "UPDATE UsersBS SET FailedAttempts = FailedAttempts + 1 WHERE LTRIM(RTRIM(UserLogin)) = LTRIM(RTRIM(@login))";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login ?? string.Empty);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void RegisterUser(string login, string password, string fullName, string phone, string email, string address)
        {
            const string query = @"
                INSERT INTO UsersBS (UserLogin, UserPassword, UserFullName, RoleID, IsBlocked, FailedAttempts, Phone, Email, Address)
                VALUES (@login, @pass, @name, @role, 0, 0, @phone, @email, @address);";

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login.Trim());
                    cmd.Parameters.AddWithValue("@pass", ComputeSha256(password));
                    cmd.Parameters.AddWithValue("@name", fullName.Trim());
                    cmd.Parameters.AddWithValue("@role", RoleIds.Client);
                    cmd.Parameters.AddWithValue("@phone", (object)NullIfEmpty(phone) ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@email", (object)NullIfEmpty(email) ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@address", (object)NullIfEmpty(address) ?? DBNull.Value);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static List<User> GetAllUsers()
        {
            var list = new List<User>();
            const string query = @"
                SELECT u.UserID, u.UserLogin, u.UserFullName, u.RoleID, r.RoleName,
                       u.IsBlocked, u.FailedAttempts, u.Phone, u.Email, u.Address
                FROM UsersBS u
                JOIN RolesBS r ON r.RoleID = u.RoleID
                ORDER BY u.RoleID, u.UserLogin;";

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read()) list.Add(MapUser(reader));
                }
            }
            return list;
        }

        public static void SetUserBlocked(int userId, bool blocked)
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("UPDATE UsersBS SET IsBlocked = @blocked, FailedAttempts = CASE WHEN @blocked = 1 THEN FailedAttempts ELSE 0 END WHERE UserID = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@blocked", blocked ? 1 : 0);
                    cmd.Parameters.AddWithValue("@id", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void ResetUserPassword(int userId, string newPassword)
        {
            if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 6)
                throw new ArgumentException("Пароль должен содержать не менее 6 символов.");

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(@"
                    UPDATE UsersBS
                    SET UserPassword = @pass, FailedAttempts = 0, IsBlocked = 0
                    WHERE UserID = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@pass", ComputeSha256(newPassword));
                    cmd.Parameters.AddWithValue("@id", userId);
                    if (cmd.ExecuteNonQuery() != 1)
                        throw new InvalidOperationException("Пользователь не найден.");
                }
            }
        }

        private static User MapUser(SqlDataReader reader)
        {
            return new User
            {
                UserID = Convert.ToInt32(reader["UserID"]),
                UserLogin = reader["UserLogin"].ToString(),
                UserFullName = reader["UserFullName"].ToString(),
                RoleID = Convert.ToInt32(reader["RoleID"]),
                RoleName = reader["RoleName"] == DBNull.Value ? string.Empty : reader["RoleName"].ToString(),
                IsBlocked = reader["IsBlocked"] != DBNull.Value && Convert.ToBoolean(reader["IsBlocked"]),
                FailedAttempts = reader["FailedAttempts"] != DBNull.Value ? Convert.ToInt32(reader["FailedAttempts"]) : 0,
                Phone = reader["Phone"] == DBNull.Value ? string.Empty : reader["Phone"].ToString(),
                Email = reader["Email"] == DBNull.Value ? string.Empty : reader["Email"].ToString(),
                Address = reader["Address"] == DBNull.Value ? string.Empty : reader["Address"].ToString()
            };
        }

        #endregion

        #region Каталог книг и издательства

        public static List<Publisher> GetAllPublishers()
        {
            var list = new List<Publisher>();
            const string query = @"SELECT PublisherID, PublisherName, ContactPerson, Phone, Email
                                   FROM PublishersBS ORDER BY PublisherName";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Publisher
                        {
                            PublisherID = Convert.ToInt32(reader["PublisherID"]),
                            PublisherName = reader["PublisherName"].ToString(),
                            ContactPerson = reader["ContactPerson"] == DBNull.Value ? string.Empty : reader["ContactPerson"].ToString(),
                            Phone = reader["Phone"] == DBNull.Value ? string.Empty : reader["Phone"].ToString(),
                            Email = reader["Email"] == DBNull.Value ? string.Empty : reader["Email"].ToString()
                        });
                    }
                }
            }
            return list;
        }

        public static List<string> GetAllGenres()
        {
            var list = new List<string>();
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT DISTINCT Genre FROM BooksBS WHERE Genre IS NOT NULL ORDER BY Genre", conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read()) list.Add(reader["Genre"].ToString());
                }
            }
            return list;
        }

        public static List<Book> GetAllBooks()
        {
            var list = new List<Book>();
            const string query = @"SELECT BookID, Title, Author, PublisherID, PublisherName, Genre,
                                          ISBN, YearPublished, Price, StockQuantity, CoverImagePath,
                                          Description, ContactPerson, PublisherPhone
                                   FROM vwBooksBS ORDER BY Title";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read()) list.Add(MapBook(reader));
                }
            }
            return list;
        }

        public static Book GetBookById(int bookId)
        {
            const string query = @"SELECT BookID, Title, Author, PublisherID, PublisherName, Genre,
                                          ISBN, YearPublished, Price, StockQuantity, CoverImagePath,
                                          Description, ContactPerson, PublisherPhone
                                   FROM vwBooksBS WHERE BookID = @id";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", bookId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) return MapBook(reader);
                    }
                }
            }
            return null;
        }

        public static void AddOrUpdateBook(Book b, bool isUpdate)
        {
            string query = isUpdate
                ? @"UPDATE BooksBS SET Title=@t, Author=@a, PublisherID=@p, Genre=@g, ISBN=@isbn,
                      YearPublished=@year, Price=@pr, StockQuantity=@s, CoverImagePath=@cover, Description=@descr
                      WHERE BookID=@id"
                : @"INSERT INTO BooksBS (Title, Author, PublisherID, Genre, ISBN, YearPublished, Price, StockQuantity, CoverImagePath, Description)
                      VALUES (@t, @a, @p, @g, @isbn, @year, @pr, @s, @cover, @descr)";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@t", b.Title.Trim());
                    cmd.Parameters.AddWithValue("@a", b.Author.Trim());
                    cmd.Parameters.AddWithValue("@p", b.PublisherID);
                    cmd.Parameters.AddWithValue("@g", (object)NullIfEmpty(b.Genre) ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@isbn", string.IsNullOrWhiteSpace(b.ISBN) ? (object)DBNull.Value : b.ISBN.Trim());
                    cmd.Parameters.AddWithValue("@year", b.YearPublished.HasValue ? (object)b.YearPublished.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@pr", b.Price);
                    cmd.Parameters.AddWithValue("@s", b.StockQuantity);
                    cmd.Parameters.AddWithValue("@cover", (object)NullIfEmpty(b.CoverImagePath) ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@descr", (object)NullIfEmpty(b.Description) ?? DBNull.Value);
                    if (isUpdate) cmd.Parameters.AddWithValue("@id", b.BookID);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static bool TryDeleteBook(int bookId, out string error)
        {
            error = null;
            try
            {
                using (var conn = new SqlConnection(ConnString))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand("DELETE FROM BooksBS WHERE BookID = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", bookId);
                        cmd.ExecuteNonQuery();
                    }
                }
                return true;
            }
            catch (SqlException ex)
            {
                error = ex.Number == 547
                    ? "Книгу нельзя удалить: она уже присутствует в заказах или корзине пользователя."
                    : "Не удалось удалить книгу: " + ex.Message;
                return false;
            }
        }

        private static Book MapBook(SqlDataReader reader)
        {
            return new Book
            {
                BookID = Convert.ToInt32(reader["BookID"]),
                Title = reader["Title"].ToString(),
                Author = reader["Author"].ToString(),
                PublisherID = Convert.ToInt32(reader["PublisherID"]),
                PublisherName = reader["PublisherName"].ToString(),
                Genre = reader["Genre"] == DBNull.Value ? string.Empty : reader["Genre"].ToString(),
                ISBN = reader["ISBN"] == DBNull.Value ? string.Empty : reader["ISBN"].ToString(),
                YearPublished = reader["YearPublished"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["YearPublished"]),
                Price = Convert.ToDecimal(reader["Price"]),
                StockQuantity = Convert.ToInt32(reader["StockQuantity"]),
                CoverImagePath = reader["CoverImagePath"] == DBNull.Value ? string.Empty : reader["CoverImagePath"].ToString(),
                Description = reader["Description"] == DBNull.Value ? string.Empty : reader["Description"].ToString(),
                PublisherContactPerson = reader["ContactPerson"] == DBNull.Value ? string.Empty : reader["ContactPerson"].ToString(),
                PublisherPhone = reader["PublisherPhone"] == DBNull.Value ? string.Empty : reader["PublisherPhone"].ToString()
            };
        }

        #endregion

        #region Корзина

        public static List<CartItem> GetCartItems(int userId)
        {
            var list = new List<CartItem>();
            const string query = @"
                SELECT c.CartItemID, c.UserID, c.Quantity,
                       b.BookID, b.Title, b.Author, b.PublisherID, b.PublisherName, b.Genre,
                       b.ISBN, b.YearPublished, b.Price, b.StockQuantity, b.CoverImagePath, b.Description,
                       b.ContactPerson, b.PublisherPhone
                FROM CartItemsBS c
                JOIN vwBooksBS b ON b.BookID = c.BookID
                WHERE c.UserID = @uid
                ORDER BY c.CartItemID;";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@uid", userId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new CartItem
                            {
                                CartItemID = Convert.ToInt32(reader["CartItemID"]),
                                UserID = Convert.ToInt32(reader["UserID"]),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                Book = MapBook(reader)
                            });
                        }
                    }
                }
            }
            return list;
        }

        public static int GetCartCount(int userId)
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("SELECT ISNULL(SUM(Quantity), 0) FROM CartItemsBS WHERE UserID = @uid", conn))
                {
                    cmd.Parameters.AddWithValue("@uid", userId);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        public static int AddToCart(int userId, int bookId, int quantity)
        {
            if (quantity <= 0) throw new ArgumentException("Количество должно быть больше нуля.");

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var tx = conn.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    try
                    {
                        int stock;
                        using (var cmd = new SqlCommand("SELECT StockQuantity FROM BooksBS WITH (UPDLOCK, HOLDLOCK) WHERE BookID = @id", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@id", bookId);
                            var value = cmd.ExecuteScalar();
                            if (value == null) throw new InvalidOperationException("Книга не найдена.");
                            stock = Convert.ToInt32(value);
                        }

                        int? existingId = null;
                        int existingQuantity = 0;
                        using (var cmd = new SqlCommand("SELECT CartItemID, Quantity FROM CartItemsBS WHERE UserID = @uid AND BookID = @bid", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@uid", userId);
                            cmd.Parameters.AddWithValue("@bid", bookId);
                            using (var reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    existingId = Convert.ToInt32(reader["CartItemID"]);
                                    existingQuantity = Convert.ToInt32(reader["Quantity"]);
                                }
                            }
                        }

                        int newQuantity = existingQuantity + quantity;
                        if (newQuantity > stock)
                            throw new InvalidOperationException(string.Format("На складе доступно только {0} шт.", stock));

                        if (existingId.HasValue)
                        {
                            using (var cmd = new SqlCommand("UPDATE CartItemsBS SET Quantity = @q WHERE CartItemID = @id", conn, tx))
                            {
                                cmd.Parameters.AddWithValue("@q", newQuantity);
                                cmd.Parameters.AddWithValue("@id", existingId.Value);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            using (var cmd = new SqlCommand("INSERT INTO CartItemsBS (UserID, BookID, Quantity) VALUES (@uid, @bid, @q)", conn, tx))
                            {
                                cmd.Parameters.AddWithValue("@uid", userId);
                                cmd.Parameters.AddWithValue("@bid", bookId);
                                cmd.Parameters.AddWithValue("@q", newQuantity);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
            return GetCartCount(userId);
        }

        public static void UpdateCartItemQuantity(int cartItemId, int quantity)
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var tx = conn.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    try
                    {
                        if (quantity <= 0)
                        {
                            using (var cmd = new SqlCommand("DELETE FROM CartItemsBS WHERE CartItemID = @id", conn, tx))
                            {
                                cmd.Parameters.AddWithValue("@id", cartItemId);
                                cmd.ExecuteNonQuery();
                            }
                            tx.Commit();
                            return;
                        }

                        int stock;
                        using (var cmd = new SqlCommand(@"
                            SELECT b.StockQuantity
                            FROM CartItemsBS c JOIN BooksBS b WITH (UPDLOCK, HOLDLOCK) ON b.BookID = c.BookID
                            WHERE c.CartItemID = @id", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@id", cartItemId);
                            var value = cmd.ExecuteScalar();
                            if (value == null) throw new InvalidOperationException("Позиция корзины не найдена.");
                            stock = Convert.ToInt32(value);
                        }

                        if (quantity > stock)
                            throw new InvalidOperationException(string.Format("На складе доступно только {0} шт.", stock));

                        using (var cmd = new SqlCommand("UPDATE CartItemsBS SET Quantity = @q WHERE CartItemID = @id", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@q", quantity);
                            cmd.Parameters.AddWithValue("@id", cartItemId);
                            cmd.ExecuteNonQuery();
                        }
                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        public static void RemoveCartItem(int cartItemId)
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("DELETE FROM CartItemsBS WHERE CartItemID = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", cartItemId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void ClearCart(int userId)
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("DELETE FROM CartItemsBS WHERE UserID = @uid", conn))
                {
                    cmd.Parameters.AddWithValue("@uid", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        #endregion

        #region Заказы

        public static int CheckoutOrder(int userId, out decimal total)
        {
            total = 0;
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var tx = conn.BeginTransaction(IsolationLevel.Serializable))
                {
                    try
                    {
                        var rows = new List<CartRow>();
                        using (var cmd = new SqlCommand(@"
                            SELECT c.BookID, c.Quantity, b.Title, b.Price, b.StockQuantity
                            FROM CartItemsBS c
                            JOIN BooksBS b WITH (UPDLOCK, HOLDLOCK) ON b.BookID = c.BookID
                            WHERE c.UserID = @uid", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@uid", userId);
                            using (var reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    rows.Add(new CartRow
                                    {
                                        BookID = Convert.ToInt32(reader["BookID"]),
                                        Quantity = Convert.ToInt32(reader["Quantity"]),
                                        Title = reader["Title"].ToString(),
                                        Price = Convert.ToDecimal(reader["Price"]),
                                        Stock = Convert.ToInt32(reader["StockQuantity"])
                                    });
                                }
                            }
                        }

                        if (rows.Count == 0)
                            throw new InvalidOperationException("Корзина пуста. Добавьте книги перед оформлением заказа.");

                        foreach (var row in rows)
                        {
                            if (row.Quantity > row.Stock)
                                throw new InvalidOperationException(string.Format(
                                    "Книги «{0}» недостаточно на складе: доступно {1} шт., в корзине {2} шт.",
                                    row.Title, row.Stock, row.Quantity));
                            total += row.Price * row.Quantity;
                        }

                        int orderId;
                        using (var cmd = new SqlCommand(@"
                            INSERT INTO OrdersBS (UserID, OrderDate, Status, TotalAmount, CreatedAt)
                            VALUES (@uid, GETDATE(), N'В обработке', @total, GETDATE());
                            SELECT CAST(SCOPE_IDENTITY() AS INT);", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@uid", userId);
                            cmd.Parameters.AddWithValue("@total", total);
                            orderId = Convert.ToInt32(cmd.ExecuteScalar());
                        }

                        foreach (var row in rows)
                        {
                            using (var cmd = new SqlCommand(@"
                                INSERT INTO OrderItemsBS (OrderID, BookID, Quantity, PriceAtPurchase)
                                VALUES (@oid, @bid, @q, @price)", conn, tx))
                            {
                                cmd.Parameters.AddWithValue("@oid", orderId);
                                cmd.Parameters.AddWithValue("@bid", row.BookID);
                                cmd.Parameters.AddWithValue("@q", row.Quantity);
                                cmd.Parameters.AddWithValue("@price", row.Price);
                                cmd.ExecuteNonQuery();
                            }

                            using (var cmd = new SqlCommand(@"
                                UPDATE BooksBS SET StockQuantity = StockQuantity - @q
                                WHERE BookID = @bid AND StockQuantity >= @q", conn, tx))
                            {
                                cmd.Parameters.AddWithValue("@q", row.Quantity);
                                cmd.Parameters.AddWithValue("@bid", row.BookID);
                                if (cmd.ExecuteNonQuery() != 1)
                                    throw new InvalidOperationException("Не удалось списать остаток книги со склада.");
                            }
                        }

                        using (var cmd = new SqlCommand("DELETE FROM CartItemsBS WHERE UserID = @uid", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@uid", userId);
                            cmd.ExecuteNonQuery();
                        }

                        tx.Commit();
                        return orderId;
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        public static List<Order> GetOrdersByUser(int userId)
        {
            return GetOrders("WHERE o.UserID = @uid", userId);
        }

        public static List<Order> GetAllOrders()
        {
            return GetOrders(null, null);
        }

        private static List<Order> GetOrders(string whereClause, int? userId)
        {
            var list = new List<Order>();
            string query = @"
                SELECT o.OrderID, o.UserID, u.UserLogin, u.UserFullName, o.OrderDate,
                       o.Status, o.TotalAmount, o.CreatedAt
                FROM OrdersBS o
                JOIN UsersBS u ON u.UserID = o.UserID
                " + (whereClause ?? string.Empty) + @"
                ORDER BY o.OrderDate DESC, o.OrderID DESC;";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    if (userId.HasValue) cmd.Parameters.AddWithValue("@uid", userId.Value);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new Order
                            {
                                OrderID = Convert.ToInt32(reader["OrderID"]),
                                UserID = Convert.ToInt32(reader["UserID"]),
                                UserLogin = reader["UserLogin"].ToString(),
                                UserFullName = reader["UserFullName"].ToString(),
                                OrderDate = Convert.ToDateTime(reader["OrderDate"]),
                                Status = reader["Status"].ToString(),
                                TotalAmount = Convert.ToDecimal(reader["TotalAmount"]),
                                CreatedAt = reader["CreatedAt"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["CreatedAt"])
                            });
                        }
                    }
                }
            }

            foreach (var order in list) order.Items = GetOrderItems(order.OrderID);
            return list;
        }

        public static Order GetOrderById(int orderId)
        {
            Order order = null;
            const string query = @"
                SELECT o.OrderID, o.UserID, u.UserLogin, u.UserFullName, o.OrderDate,
                       o.Status, o.TotalAmount, o.CreatedAt
                FROM OrdersBS o
                JOIN UsersBS u ON u.UserID = o.UserID
                WHERE o.OrderID = @id";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", orderId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            order = new Order
                            {
                                OrderID = Convert.ToInt32(reader["OrderID"]),
                                UserID = Convert.ToInt32(reader["UserID"]),
                                UserLogin = reader["UserLogin"].ToString(),
                                UserFullName = reader["UserFullName"].ToString(),
                                OrderDate = Convert.ToDateTime(reader["OrderDate"]),
                                Status = reader["Status"].ToString(),
                                TotalAmount = Convert.ToDecimal(reader["TotalAmount"]),
                                CreatedAt = reader["CreatedAt"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["CreatedAt"])
                            };
                        }
                    }
                }
            }
            if (order != null) order.Items = GetOrderItems(order.OrderID);
            return order;
        }

        public static List<OrderItem> GetOrderItems(int orderId)
        {
            var list = new List<OrderItem>();
            const string query = @"
                SELECT oi.OrderItemID, oi.OrderID, oi.BookID, b.Title, b.Author,
                       oi.Quantity, oi.PriceAtPurchase
                FROM OrderItemsBS oi
                JOIN BooksBS b ON b.BookID = oi.BookID
                WHERE oi.OrderID = @oid
                ORDER BY oi.OrderItemID";
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@oid", orderId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new OrderItem
                            {
                                OrderItemID = Convert.ToInt32(reader["OrderItemID"]),
                                OrderID = Convert.ToInt32(reader["OrderID"]),
                                BookID = Convert.ToInt32(reader["BookID"]),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                PriceAtPurchase = Convert.ToDecimal(reader["PriceAtPurchase"])
                            });
                        }
                    }
                }
            }
            return list;
        }

        public static void UpdateOrderStatus(int orderId, string newStatus, bool restoreStock)
        {
            var allowed = new[] { "В обработке", "Собирается", "Выполнен", "Отменён" };
            if (!allowed.Contains(newStatus)) throw new ArgumentException("Недопустимый статус заказа.");

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var tx = conn.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    try
                    {
                        string currentStatus;
                        using (var cmd = new SqlCommand("SELECT Status FROM OrdersBS WITH (UPDLOCK, HOLDLOCK) WHERE OrderID = @id", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@id", orderId);
                            var value = cmd.ExecuteScalar();
                            if (value == null) throw new InvalidOperationException("Заказ не найден.");
                            currentStatus = value.ToString();
                        }

                        if (currentStatus == newStatus)
                        {
                            tx.Commit();
                            return;
                        }

                        if (currentStatus == "Отменён" && newStatus != "Отменён")
                            throw new InvalidOperationException("Отменённый заказ нельзя вернуть в работу.");

                        if (currentStatus == "Выполнен" && newStatus == "Отменён")
                            throw new InvalidOperationException("Выполненный заказ нельзя отменить.");

                        if (newStatus == "Отменён" && restoreStock)
                        {
                            using (var cmd = new SqlCommand(@"
                                UPDATE b SET b.StockQuantity = b.StockQuantity + oi.Quantity
                                FROM BooksBS b
                                JOIN OrderItemsBS oi ON oi.BookID = b.BookID
                                WHERE oi.OrderID = @id", conn, tx))
                            {
                                cmd.Parameters.AddWithValue("@id", orderId);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        using (var cmd = new SqlCommand("UPDATE OrdersBS SET Status = @status WHERE OrderID = @id", conn, tx))
                        {
                            cmd.Parameters.AddWithValue("@status", newStatus);
                            cmd.Parameters.AddWithValue("@id", orderId);
                            cmd.ExecuteNonQuery();
                        }
                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        public static void CancelOrder(int orderId, int userId, bool isStaff)
        {
            var order = GetOrderById(orderId);
            if (order == null) throw new InvalidOperationException("Заказ не найден.");
            if (!isStaff && order.UserID != userId)
                throw new InvalidOperationException("Вы не можете отменить чужой заказ.");
            if (!isStaff && !order.CanCancel)
                throw new InvalidOperationException("Заказ уже выполнен или отменён.");
            UpdateOrderStatus(orderId, "Отменён", true);
        }

        public static int SimulateStatusChanges()
        {
            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(@"
                    UPDATE OrdersBS
                    SET Status = N'Собирается'
                    WHERE Status = N'В обработке'
                      AND ISNULL(CreatedAt, OrderDate) < DATEADD(MINUTE, -2, GETDATE());", conn))
                {
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        #endregion

        #region Отчёты

        public static SalesReport GetSalesReport(DateTime from, DateTime to)
        {
            var report = new SalesReport { DateFrom = from.Date, DateTo = to.Date };

            using (var conn = new SqlConnection(ConnString))
            {
                conn.Open();

                using (var cmd = new SqlCommand(@"
                    SELECT COUNT(*) AS OrdersCount,
                           ISNULL(SUM(TotalAmount), 0) AS Revenue,
                           ISNULL(AVG(TotalAmount), 0) AS AverageOrder
                    FROM OrdersBS
                    WHERE Status <> N'Отменён' AND OrderDate >= @from AND OrderDate < @to", conn))
                {
                    cmd.Parameters.AddWithValue("@from", from.Date);
                    cmd.Parameters.AddWithValue("@to", to.Date.AddDays(1));
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            report.OrdersCount = Convert.ToInt32(reader["OrdersCount"]);
                            report.Revenue = Convert.ToDecimal(reader["Revenue"]);
                            report.AverageOrder = Convert.ToDecimal(reader["AverageOrder"]);
                        }
                    }
                }

                using (var cmd = new SqlCommand(@"
                    SELECT ISNULL(SUM(oi.Quantity), 0) AS BooksSold
                    FROM OrderItemsBS oi
                    JOIN OrdersBS o ON o.OrderID = oi.OrderID
                    WHERE o.Status <> N'Отменён' AND o.OrderDate >= @from AND o.OrderDate < @to", conn))
                {
                    cmd.Parameters.AddWithValue("@from", from.Date);
                    cmd.Parameters.AddWithValue("@to", to.Date.AddDays(1));
                    report.BooksSold = Convert.ToInt32(cmd.ExecuteScalar());
                }

                using (var cmd = new SqlCommand(@"
                    SELECT TOP 5 b.BookID, b.Title, b.Author,
                           SUM(oi.Quantity) AS Quantity,
                           SUM(oi.Quantity * oi.PriceAtPurchase) AS Revenue
                    FROM OrderItemsBS oi
                    JOIN OrdersBS o ON o.OrderID = oi.OrderID
                    JOIN BooksBS b ON b.BookID = oi.BookID
                    WHERE o.Status <> N'Отменён' AND o.OrderDate >= @from AND o.OrderDate < @to
                    GROUP BY b.BookID, b.Title, b.Author
                    ORDER BY SUM(oi.Quantity) DESC, SUM(oi.Quantity * oi.PriceAtPurchase) DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@from", from.Date);
                    cmd.Parameters.AddWithValue("@to", to.Date.AddDays(1));
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            report.TopBooks.Add(new TopBookRow
                            {
                                BookID = Convert.ToInt32(reader["BookID"]),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                Quantity = Convert.ToInt32(reader["Quantity"]),
                                Revenue = Convert.ToDecimal(reader["Revenue"])
                            });
                        }
                    }
                }
            }
            return report;
        }

        #endregion

        private static string NullIfEmpty(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        }

        private class CartRow
        {
            public int BookID { get; set; }
            public int Quantity { get; set; }
            public string Title { get; set; }
            public decimal Price { get; set; }
            public int Stock { get; set; }
        }
    }
}
