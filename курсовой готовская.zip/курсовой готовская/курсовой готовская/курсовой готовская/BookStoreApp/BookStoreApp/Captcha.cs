﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BookStoreApp
{
    public static class Captcha
    {
        private const string Chars = "ABCDEFGHJKLMNPQRSTUVWXYZ123456789";
        public static string CurrentText { get; private set; }

        public static BitmapSource GenerateImage(int width = 150, int height = 50)
        {
            var rnd = new Random();
            var charsArr = new char[4];
            for (int i = 0; i < 4; i++) charsArr[i] = Chars[rnd.Next(Chars.Length)];
            CurrentText = new string(charsArr);

            var visual = new DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                dc.DrawRectangle(Brushes.WhiteSmoke, null, new Rect(0, 0, width, height));

                // Шум (линии)
                for (int i = 0; i < 15; i++)
                {
                    var pen = new Pen(new SolidColorBrush(Color.FromRgb((byte)rnd.Next(150, 200), (byte)rnd.Next(150, 200), (byte)rnd.Next(150, 200))), 1);
                    dc.DrawLine(pen, new Point(rnd.Next(width), rnd.Next(height)), new Point(rnd.Next(width), rnd.Next(height)));
                }

                // Текст
                for (int i = 0; i < CurrentText.Length; i++)
                {
                    var typeface = new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Bold, FontStretches.Normal);
                    var formattedText = new FormattedText(
                        CurrentText[i].ToString(),
                        CultureInfo.InvariantCulture,
                        FlowDirection.LeftToRight,
                        typeface,
                        24,
                        new SolidColorBrush(Color.FromRgb((byte)rnd.Next(0, 100), (byte)rnd.Next(0, 100), (byte)rnd.Next(0, 100))),
                        96);

                    double x = 15 + i * 30 + rnd.Next(-5, 5);
                    double y = 10 + rnd.Next(-5, 10);

                    dc.PushTransform(new RotateTransform(rnd.Next(-20, 20), x + 10, y + 15));
                    dc.DrawText(formattedText, new Point(x, y));
                    dc.Pop();
                }
            }

            var bmp = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            bmp.Render(visual);
            bmp.Freeze();
            return bmp;
        }
    }
}