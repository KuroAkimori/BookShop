﻿using System;
using System.Windows;

namespace BookStoreApp
{
    public partial class RegisterWindow : Window
    {
        public string RegisteredLogin { get; private set; }

        public RegisterWindow()
        {
            InitializeComponent();
            ThemeToggle.IsChecked = ThemeManager.IsDark;
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.ApplyTheme(ThemeToggle.IsChecked == true);
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            TxtError.Text = string.Empty;

            string fullName = TxtFullName.Text.Trim();
            string login = TxtLogin.Text.Trim();
            string password = TxtPassword.Password;
            string phone = TxtPhone.Text.Trim();
            string email = TxtEmail.Text.Trim();
            string address = TxtAddress.Text.Trim();

            if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(login) ||
                string.IsNullOrWhiteSpace(password))
            {
                TxtError.Text = "Заполните обязательные поля: ФИО, логин и пароль.";
                return;
            }

            if (fullName.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length < 2)
            {
                TxtError.Text = "Укажите фамилию и имя полностью.";
                return;
            }

            if (login.Length < 3)
            {
                TxtError.Text = "Логин должен содержать не менее 3 символов.";
                return;
            }

            if (password.Length < 6)
            {
                TxtError.Text = "Пароль должен содержать не менее 6 символов.";
                return;
            }

            if (password != TxtPasswordConfirm.Password)
            {
                TxtError.Text = "Пароли не совпадают.";
                return;
            }

            if (!string.IsNullOrWhiteSpace(email) &&
                (!email.Contains("@") || !email.Contains(".")))
            {
                TxtError.Text = "Укажите корректный адрес электронной почты.";
                return;
            }

            try
            {
                if (DatabaseHelper.LoginExists(login))
                {
                    TxtError.Text = "Пользователь с таким логином уже существует.";
                    return;
                }

                DatabaseHelper.RegisterUser(login, password, fullName, phone, email, address);
                RegisteredLogin = login;
                MessageBox.Show("Регистрация завершена. Теперь вы можете войти в личный кабинет.",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                TxtError.Text = "Не удалось зарегистрироваться: " + ex.Message;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
