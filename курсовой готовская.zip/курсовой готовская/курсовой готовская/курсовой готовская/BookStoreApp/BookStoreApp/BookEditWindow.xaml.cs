﻿using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace BookStoreApp
{
    public partial class BookEditWindow : Window
    {
        private readonly Book CurrentBook;
        private string currentCoverFile;
        private string pendingCoverSource;
        private bool coverRemoved;

        public BookEditWindow(Book book = null)
        {
            InitializeComponent();
            LoadPublishers();

            if (book != null)
            {
                CurrentBook = book;
                currentCoverFile = book.CoverImagePath;
                TxtHeader.Text = "Редактирование книги";
                TxtTitle.Text = book.Title;
                TxtAuthor.Text = book.Author;
                TxtGenre.Text = book.Genre;
                TxtIsbn.Text = book.ISBN;
                TxtYear.Text = book.YearPublished.HasValue ? book.YearPublished.Value.ToString() : string.Empty;
                TxtPrice.Text = book.Price.ToString("F2");
                TxtStock.Text = book.StockQuantity.ToString();
                TxtDescription.Text = book.Description;

                for (int i = 0; i < CmbPublisher.Items.Count; i++)
                {
                    var item = CmbPublisher.Items[i] as ComboBoxItem;
                    if (item != null && item.Tag is int && (int)item.Tag == book.PublisherID)
                    {
                        CmbPublisher.SelectedIndex = i;
                        break;
                    }
                }

                UpdateCoverPreview(book.CoverImagePath);
            }
            else
            {
                TxtHeader.Text = "Добавление книги";
                currentCoverFile = null;
                if (CmbPublisher.Items.Count > 0) CmbPublisher.SelectedIndex = 0;
                UpdateCoverPreview(null);
            }
        }

        private void LoadPublishers()
        {
            var publishers = DatabaseHelper.GetAllPublishers();
            foreach (var p in publishers)
                CmbPublisher.Items.Add(new ComboBoxItem { Content = p.PublisherName, Tag = p.PublisherID });
        }

        private void UpdateCoverPreview(string fileNameOrPath)
        {
            string path = null;
            if (!string.IsNullOrWhiteSpace(fileNameOrPath))
            {
                path = Path.IsPathRooted(fileNameOrPath)
                    ? (File.Exists(fileNameOrPath) ? fileNameOrPath : null)
                    : CoverStorage.Resolve(fileNameOrPath);
            }

            if (string.IsNullOrWhiteSpace(path))
            {
                ImgCover.Source = null;
                CoverPlaceholder.Visibility = Visibility.Visible;
                TxtCoverHint.Text = "Обложка не выбрана";
                return;
            }

            try
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = new Uri(path, UriKind.Absolute);
                image.EndInit();
                image.Freeze();
                ImgCover.Source = image;
                CoverPlaceholder.Visibility = Visibility.Collapsed;
                TxtCoverHint.Text = Path.GetFileName(path);
            }
            catch
            {
                ImgCover.Source = null;
                CoverPlaceholder.Visibility = Visibility.Visible;
                TxtCoverHint.Text = "Не удалось прочитать изображение";
            }
        }

        private void BtnSelectCover_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Выбор обложки книги",
                Filter = "Изображения (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.bmp;*.gif"
            };
            if (dialog.ShowDialog() != true) return;

            pendingCoverSource = dialog.FileName;
            coverRemoved = false;
            UpdateCoverPreview(pendingCoverSource);
        }

        private void BtnRemoveCover_Click(object sender, RoutedEventArgs e)
        {
            pendingCoverSource = null;
            coverRemoved = true;
            UpdateCoverPreview(null);
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            TxtError.Text = string.Empty;

            if (string.IsNullOrWhiteSpace(TxtTitle.Text) || string.IsNullOrWhiteSpace(TxtAuthor.Text))
            {
                TxtError.Text = "Название и автор обязательны.";
                return;
            }

            decimal price;
            if (!TryParseMoney(TxtPrice.Text, out price))
            {
                TxtError.Text = "Некорректная цена.";
                return;
            }

            int stock;
            if (!int.TryParse(TxtStock.Text.Trim(), out stock) || stock < 0)
            {
                TxtError.Text = "Некорректное количество на складе.";
                return;
            }

            int? year = null;
            if (!string.IsNullOrWhiteSpace(TxtYear.Text))
            {
                int parsedYear;
                if (!int.TryParse(TxtYear.Text.Trim(), out parsedYear) || parsedYear < 1400 || parsedYear > 2100)
                {
                    TxtError.Text = "Год издания должен быть числом от 1400 до 2100.";
                    return;
                }
                year = parsedYear;
            }

            if (CmbPublisher.SelectedItem == null)
            {
                TxtError.Text = "Выберите издательство.";
                return;
            }

            if (TxtIsbn.Text.Trim().Length > 20)
            {
                TxtError.Text = "ISBN не должен превышать 20 символов.";
                return;
            }

            int publisherId = (int)((ComboBoxItem)CmbPublisher.SelectedItem).Tag;

            string finalCover = currentCoverFile;
            if (!string.IsNullOrWhiteSpace(pendingCoverSource))
            {
                try
                {
                    finalCover = CoverStorage.Save(pendingCoverSource, currentCoverFile);
                }
                catch (Exception ex)
                {
                    TxtError.Text = "Не удалось сохранить обложку: " + ex.Message;
                    return;
                }
            }
            else if (coverRemoved)
            {
                CoverStorage.TryDelete(currentCoverFile);
                finalCover = null;
            }

            var bookToSave = new Book
            {
                BookID = CurrentBook == null ? 0 : CurrentBook.BookID,
                Title = TxtTitle.Text.Trim(),
                Author = TxtAuthor.Text.Trim(),
                PublisherID = publisherId,
                Genre = TxtGenre.Text.Trim(),
                ISBN = TxtIsbn.Text.Trim(),
                YearPublished = year,
                Price = price,
                StockQuantity = stock,
                CoverImagePath = finalCover,
                Description = TxtDescription.Text.Trim()
            };

            try
            {
                DatabaseHelper.AddOrUpdateBook(bookToSave, CurrentBook != null);
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                TxtError.Text = "Ошибка сохранения: " + ex.Message;
            }
        }

        private static bool TryParseMoney(string text, out decimal value)
        {
            string clean = (text ?? string.Empty).Trim();
            if (decimal.TryParse(clean, NumberStyles.Number, CultureInfo.CurrentCulture, out value))
                return value >= 0;
            return decimal.TryParse(clean.Replace(',', '.'), NumberStyles.Number,
                CultureInfo.InvariantCulture, out value) && value >= 0;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
