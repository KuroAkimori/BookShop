using System;
using System.IO;

namespace BookStoreApp
{
    /// <summary>Хранение обложек книг в папке Covers рядом с исполняемым файлом.</summary>
    public static class CoverStorage
    {
        public static string CoversDirectory
        {
            get
            {
                string dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Covers");
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                return dir;
            }
        }

        public static string Resolve(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName)) return string.Empty;
            if (Path.IsPathRooted(fileName)) return File.Exists(fileName) ? fileName : string.Empty;
            string full = Path.Combine(CoversDirectory, fileName);
            return File.Exists(full) ? full : string.Empty;
        }

        public static string Save(string sourcePath, string previousFileName)
        {
            if (string.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath))
                throw new FileNotFoundException("Файл обложки не найден.", sourcePath);

            string extension = Path.GetExtension(sourcePath);
            if (string.IsNullOrWhiteSpace(extension)) extension = ".jpg";
            string newFileName = Guid.NewGuid().ToString("N") + extension.ToLowerInvariant();
            string destination = Path.Combine(CoversDirectory, newFileName);
            File.Copy(sourcePath, destination, true);

            if (!string.IsNullOrWhiteSpace(previousFileName) &&
                !string.Equals(previousFileName, newFileName, StringComparison.OrdinalIgnoreCase))
            {
                TryDelete(previousFileName);
            }
            return newFileName;
        }

        public static void TryDelete(string fileName)
        {
            try
            {
                string full = Resolve(fileName);
                if (!string.IsNullOrWhiteSpace(full) && File.Exists(full)) File.Delete(full);
            }
            catch
            {
                // Удаление обложки не должно блокировать сохранение книги.
            }
        }
    }
}
