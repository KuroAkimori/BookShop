using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BookStoreApp
{
    public partial class CartWindow : Window
    {
        private readonly User CurrentUser;
        private List<CartItem> Items = new List<CartItem>();

        public CartWindow(User user)
        {
            InitializeComponent();
            CurrentUser = user;
            ThemeToggle.IsChecked = ThemeManager.IsDark;
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
            LoadCart();
        }

        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.ApplyTheme(ThemeToggle.IsChecked == true);
            ThemeToggle.Content = ThemeManager.IconForCurrentTheme;
        }

        private void LoadCart()
        {
            try
            {
                Items = DatabaseHelper.GetCartItems(CurrentUser.UserID);
                IcCartItems.ItemsSource = null;
                IcCartItems.ItemsSource = Items;

                decimal total = Items.Sum(i => i.Total);
                int positions = Items.Count;
                int count = Items.Sum(i => i.Quantity);

                TxtTotal.Text = string.Format("{0:N2} ₽", total);
                TxtSubtitle.Text = positions == 0
                    ? "Проверьте состав заказа"
                    : string.Format("{0} позиций · {1} шт. · к оплате {2:N2} ₽", positions, count, total);
                EmptyState.Visibility = positions == 0 ? Visibility.Visible : Visibility.Collapsed;
                ScrollItems.Visibility = positions == 0 ? Visibility.Collapsed : Visibility.Visible;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить корзину.\n\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnPlus_Click(object sender, RoutedEventArgs e)
        {
            var item = (sender as Button)?.Tag as CartItem;
            if (item == null) return;
            ChangeQuantity(item, item.Quantity + 1);
        }

        private void BtnMinus_Click(object sender, RoutedEventArgs e)
        {
            var item = (sender as Button)?.Tag as CartItem;
            if (item == null) return;
            ChangeQuantity(item, item.Quantity - 1);
        }

        private void ChangeQuantity(CartItem item, int quantity)
        {
            try
            {
                DatabaseHelper.UpdateCartItemQuantity(item.CartItemID, quantity);
                LoadCart();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Корзина", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            var item = (sender as Button)?.Tag as CartItem;
            if (item == null) return;
            if (MessageBox.Show(string.Format("Удалить «{0}» из корзины?", item.Book.Title), "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try
            {
                DatabaseHelper.RemoveCartItem(item.CartItemID);
                LoadCart();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Корзина", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            if (Items.Count == 0) return;
            if (MessageBox.Show("Очистить корзину полностью?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try
            {
                DatabaseHelper.ClearCart(CurrentUser.UserID);
                LoadCart();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Корзина", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnCheckout_Click(object sender, RoutedEventArgs e)
        {
            if (Items.Count == 0)
            {
                MessageBox.Show("Корзина пуста.", "Оформление заказа", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            decimal previewTotal = Items.Sum(i => i.Total);
            var answer = MessageBox.Show(
                string.Format("Оформить заказ на сумму {0:N2} ₽?\n\nТовары будут списаны со склада.", previewTotal),
                "Подтверждение заказа", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (answer != MessageBoxResult.Yes) return;

            try
            {
                decimal total;
                int orderId = DatabaseHelper.CheckoutOrder(CurrentUser.UserID, out total);
                var order = DatabaseHelper.GetOrderById(orderId);
                var receipt = new ReceiptWindow(order) { Owner = this };
                receipt.ShowDialog();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка оформления заказа", MessageBoxButton.OK, MessageBoxImage.Warning);
                LoadCart();
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
