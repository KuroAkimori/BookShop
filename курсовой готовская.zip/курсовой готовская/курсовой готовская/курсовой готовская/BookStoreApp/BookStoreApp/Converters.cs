using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BookStoreApp
{
    /// <summary>Загружает обложку книги по имени файла; при отсутствии возвращает null.</summary>
    public class CoverPathConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string path = CoverStorage.Resolve(value as string);
            if (string.IsNullOrWhiteSpace(path)) return null;
            try
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = new Uri(path, UriKind.Absolute);
                image.EndInit();
                image.Freeze();
                return image;
            }
            catch
            {
                return null;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }

    /// <summary>Цвет фона для статуса заказа.</summary>
    public class StatusToBrushConverter : IValueConverter
    {
        private static readonly Brush Processing = Create("#FFF2D9");
        private static readonly Brush Packing = Create("#DDEBFF");
        private static readonly Brush Completed = Create("#DDF4E1");
        private static readonly Brush Cancelled = Create("#FADCDC");
        private static readonly Brush Default = Create("#EEEEEE");

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string status = value as string;
            switch (status)
            {
                case "В обработке": return Processing;
                case "Собирается": return Packing;
                case "Выполнен": return Completed;
                case "Отменён": return Cancelled;
                default: return Default;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }

        private static Brush Create(string color)
        {
            var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));
            brush.Freeze();
            return brush;
        }
    }

    /// <summary>Цвет текста для статуса заказа.</summary>
    public class StatusToForegroundConverter : IValueConverter
    {
        private static readonly Brush Processing = Create("#9A5B00");
        private static readonly Brush Packing = Create("#1B4F9C");
        private static readonly Brush Completed = Create("#1E6B34");
        private static readonly Brush Cancelled = Create("#A32020");
        private static readonly Brush Default = Create("#555555");

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string status = value as string;
            switch (status)
            {
                case "В обработке": return Processing;
                case "Собирается": return Packing;
                case "Выполнен": return Completed;
                case "Отменён": return Cancelled;
                default: return Default;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }

        private static Brush Create(string color)
        {
            var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));
            brush.Freeze();
            return brush;
        }
    }

    /// <summary>Красный цвет для отсутствующего товара, зелёный — для товара в наличии.</summary>
    public class StockToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int stock = 0;
            if (value != null) int.TryParse(value.ToString(), out stock);
            return stock > 0
                ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2E7D48"))
                : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#C0392B"));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }

    public class BoolToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool flag = value is bool && (bool)value;
            if (parameter != null && parameter.ToString() == "invert") flag = !flag;
            return flag ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }

    public class InverseBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return !(value is bool && (bool)value);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return !(value is bool && (bool)value);
        }
    }
}
