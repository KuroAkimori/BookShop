namespace BookStoreApi.Models;

public sealed record LoginRequest(string Login, string Password);

public sealed record LoginResponse(
    int UserId,
    string Login,
    string FullName,
    string Role,
    string Token,
    DateTime ExpiresAt);

public sealed record BookDto(
    int BookID,
    string Title,
    string Author,
    string Genre,
    string PublisherName,
    string ISBN,
    int? YearPublished,
    decimal Price,
    int StockQuantity,
    string? Description,
    string? CoverImagePath);

public sealed record OrderItemDto(
    int BookID,
    string Title,
    int Quantity,
    decimal PriceAtPurchase,
    decimal Total);

public sealed record OrderDto(
    int OrderID,
    int UserID,
    string UserLogin,
    string UserFullName,
    DateTime OrderDate,
    string Status,
    decimal TotalAmount,
    DateTime CreatedAt,
    IReadOnlyList<OrderItemDto> Items);

public sealed record CreateOrderItem(int BookID, int Quantity);

public sealed record CreateOrderRequest(IReadOnlyList<CreateOrderItem> Items);

public sealed record StatusUpdateRequest(string Status);

public sealed record SalesReportRow(DateOnly Day, int OrdersCount, int BooksSold, decimal Revenue);

public sealed record TopBookRow(int BookID, string Title, int BooksSold, decimal Revenue);
