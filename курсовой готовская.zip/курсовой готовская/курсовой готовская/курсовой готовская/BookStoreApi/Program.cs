using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using BookStoreApi.Data;
using BookStoreApi.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// ---------- Сервисы ----------
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "BookStore REST API",
        Version = "v1",
        Description = "Программный интерфейс книжного магазина BookStore: каталог, заказы, статусы и отчёты. " +
                      "Авторизация выполняется по JWT-токену, полученному в методе /api/auth/login."
    });

    var scheme = new OpenApiSecurityScheme
    {
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        Description = "Введите JWT-токен, полученный при входе.",
        Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
    };

    options.AddSecurityDefinition("Bearer", scheme);
    options.AddSecurityRequirement(new OpenApiSecurityRequirement { { scheme, Array.Empty<string>() } });
});

var jwt = builder.Configuration.GetSection("Jwt");
var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt["Issuer"],
            ValidateAudience = true,
            ValidAudience = jwt["Audience"],
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = signingKey,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromSeconds(30),
            NameClaimType = ClaimTypes.Name,
            RoleClaimType = ClaimTypes.Role
        };
    });

builder.Services.AddAuthorization();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));
builder.Services.AddSingleton<Db>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "BookStore API v1");
    options.DocumentTitle = "BookStore REST API";
    options.DefaultModelsExpandDepth(-1);
});

app.UseCors();
app.UseAuthentication();
app.UseAuthorization();

// ---------- Вспомогательные функции ----------
static string HashPassword(string password) =>
    Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(password))).ToLowerInvariant();

static string RoleName(int roleId) => roleId switch
{
    1 => "Admin",
    3 => "Manager",
    _ => "Client"
};

static int CurrentUserId(ClaimsPrincipal user) =>
    int.Parse(user.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");

static BookDto ReadBook(SqlDataReader reader) => new(
    reader.GetInt32(reader.GetOrdinal("BookID")),
    reader.GetString(reader.GetOrdinal("Title")),
    reader.GetString(reader.GetOrdinal("Author")),
    reader.GetString(reader.GetOrdinal("Genre")),
    reader.GetString(reader.GetOrdinal("PublisherName")),
    reader.GetString(reader.GetOrdinal("ISBN")),
    reader["YearPublished"] is DBNull ? null : Convert.ToInt32(reader["YearPublished"]),
    reader.GetDecimal(reader.GetOrdinal("Price")),
    reader.GetInt32(reader.GetOrdinal("StockQuantity")),
    reader["Description"] is DBNull ? null : reader.GetString(reader.GetOrdinal("Description")),
    reader["CoverImagePath"] is DBNull ? null : reader.GetString(reader.GetOrdinal("CoverImagePath")));

// ---------- Авторизация ----------
app.MapPost("/api/auth/login", (LoginRequest request, Db db, IConfiguration config) =>
{
    if (string.IsNullOrWhiteSpace(request.Login) || string.IsNullOrWhiteSpace(request.Password))
        return Results.BadRequest(new { message = "Логин и пароль обязательны." });

    using var connection = db.Open();
    using var command = new SqlCommand(@"
        SELECT UserID, UserLogin, UserFullName, UserPassword, RoleID, IsBlocked
        FROM UsersBS WHERE UserLogin = @login;", connection);
    command.Parameters.AddWithValue("@login", request.Login.Trim());

    using var reader = command.ExecuteReader();
    if (!reader.Read())
        return Results.Unauthorized();

    var userId = reader.GetInt32(reader.GetOrdinal("UserID"));
    var login = reader.GetString(reader.GetOrdinal("UserLogin"));
    var fullName = reader.GetString(reader.GetOrdinal("UserFullName"));
    var storedHash = reader.GetString(reader.GetOrdinal("UserPassword")).Trim().ToLowerInvariant();
    var roleId = reader.GetInt32(reader.GetOrdinal("RoleID"));
    var isBlocked = reader.GetBoolean(reader.GetOrdinal("IsBlocked"));
    reader.Close();

    if (isBlocked)
        return Results.Json(new { message = "Учётная запись заблокирована." }, statusCode: StatusCodes.Status403Forbidden);

    if (!CryptographicOperations.FixedTimeEquals(
            Encoding.ASCII.GetBytes(storedHash),
            Encoding.ASCII.GetBytes(HashPassword(request.Password))))
    {
        using var fail = new SqlCommand("UPDATE UsersBS SET FailedAttempts = FailedAttempts + 1 WHERE UserID = @id", connection);
        fail.Parameters.AddWithValue("@id", userId);
        fail.ExecuteNonQuery();
        return Results.Unauthorized();
    }

    using (var reset = new SqlCommand("UPDATE UsersBS SET FailedAttempts = 0 WHERE UserID = @id", connection))
    {
        reset.Parameters.AddWithValue("@id", userId);
        reset.ExecuteNonQuery();
    }

    var role = RoleName(roleId);
    var lifetime = int.TryParse(config["Jwt:LifetimeMinutes"], out var minutes) ? minutes : 120;
    var expires = DateTime.UtcNow.AddMinutes(lifetime);

    var claims = new[]
    {
        new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
        new Claim(ClaimTypes.Name, login),
        new Claim(ClaimTypes.Role, role),
        new Claim("fullName", fullName)
    };

    var token = new JwtSecurityToken(
        issuer: config["Jwt:Issuer"],
        audience: config["Jwt:Audience"],
        claims: claims,
        expires: expires,
        signingCredentials: new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256));

    var jwtToken = new JwtSecurityTokenHandler().WriteToken(token);
    return Results.Ok(new LoginResponse(userId, login, fullName, role, jwtToken, expires));
})
.WithTags("Авторизация")
.WithSummary("Вход в систему и получение JWT-токена")
.AllowAnonymous();

// ---------- Каталог ----------
app.MapGet("/api/books", (Db db, string? search, string? genre, string? publisher, string? sort) =>
{
    var orderBy = sort?.ToLowerInvariant() switch
    {
        "price_asc" => "Price ASC",
        "price_desc" => "Price DESC",
        "title" => "Title ASC",
        "year" => "YearPublished DESC",
        _ => "Title ASC"
    };

    using var connection = db.Open();
    using var command = new SqlCommand($@"
        SELECT BookID, Title, Author, Genre, PublisherName, ISBN, YearPublished,
               Price, StockQuantity, Description, CoverImagePath
        FROM vwBooksBS
        WHERE (@search IS NULL OR Title LIKE @like OR Author LIKE @like OR ISBN LIKE @like)
          AND (@genre IS NULL OR Genre = @genre)
          AND (@publisher IS NULL OR PublisherName = @publisher)
        ORDER BY {orderBy};", connection);

    command.Parameters.AddWithValue("@search", string.IsNullOrWhiteSpace(search) ? DBNull.Value : search.Trim());
    command.Parameters.AddWithValue("@like", "%" + (search ?? string.Empty).Trim() + "%");
    command.Parameters.AddWithValue("@genre", string.IsNullOrWhiteSpace(genre) ? DBNull.Value : genre);
    command.Parameters.AddWithValue("@publisher", string.IsNullOrWhiteSpace(publisher) ? DBNull.Value : publisher);

    var books = new List<BookDto>();
    using var reader = command.ExecuteReader();
    while (reader.Read()) books.Add(ReadBook(reader));
    return Results.Ok(books);
})
.WithTags("Каталог")
.WithSummary("Список книг с поиском, фильтрами и сортировкой")
.AllowAnonymous();

app.MapGet("/api/books/{id:int}", (int id, Db db) =>
{
    using var connection = db.Open();
    using var command = new SqlCommand(@"
        SELECT BookID, Title, Author, Genre, PublisherName, ISBN, YearPublished,
               Price, StockQuantity, Description, CoverImagePath
        FROM vwBooksBS WHERE BookID = @id;", connection);
    command.Parameters.AddWithValue("@id", id);

    using var reader = command.ExecuteReader();
    return reader.Read() ? Results.Ok(ReadBook(reader)) : Results.NotFound();
})
.WithTags("Каталог")
.WithSummary("Карточка книги по идентификатору")
.AllowAnonymous();

app.MapGet("/api/books/filters", (Db db) =>
{
    using var connection = db.Open();
    var genres = new List<string>();
    var publishers = new List<string>();

    using (var command = new SqlCommand("SELECT DISTINCT Genre FROM BooksBS ORDER BY Genre;", connection))
    using (var reader = command.ExecuteReader())
        while (reader.Read()) genres.Add(reader.GetString(0));

    using (var command = new SqlCommand("SELECT DISTINCT PublisherName FROM vwBooksBS ORDER BY PublisherName;", connection))
    using (var reader = command.ExecuteReader())
        while (reader.Read()) publishers.Add(reader.GetString(0));

    return Results.Ok(new { genres, publishers });
})
.WithTags("Каталог")
.WithSummary("Справочники жанров и издательств для фильтров")
.AllowAnonymous();

// ---------- Заказы ----------
app.MapGet("/api/orders", (Db db, string? status) =>
{
    using var connection = db.Open();
    using var command = new SqlCommand(@"
        SELECT o.OrderID, o.UserID, u.UserLogin, u.UserFullName,
               o.OrderDate, o.Status, o.TotalAmount, o.CreatedAt
        FROM OrdersBS o
        JOIN UsersBS u ON u.UserID = o.UserID
        WHERE (@status IS NULL OR o.Status = @status)
        ORDER BY o.OrderDate DESC, o.OrderID DESC;", connection);
    command.Parameters.AddWithValue("@status", string.IsNullOrWhiteSpace(status) ? DBNull.Value : status);

    var orders = new List<OrderDto>();
    using (var reader = command.ExecuteReader())
    {
        while (reader.Read())
        {
            orders.Add(new OrderDto(
                reader.GetInt32(reader.GetOrdinal("OrderID")),
                reader.GetInt32(reader.GetOrdinal("UserID")),
                reader.GetString(reader.GetOrdinal("UserLogin")),
                reader.GetString(reader.GetOrdinal("UserFullName")),
                reader.GetDateTime(reader.GetOrdinal("OrderDate")),
                reader.GetString(reader.GetOrdinal("Status")),
                reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                reader.GetDateTime(reader.GetOrdinal("CreatedAt")),
                Array.Empty<OrderItemDto>()));
        }
    }

    // Догружаем позиции одним запросом и распределяем по заказам
    if (orders.Count > 0)
    {
        var ids = string.Join(",", orders.Select(o => o.OrderID));
        var itemsByOrder = new Dictionary<int, List<OrderItemDto>>();
        using var itemCommand = new SqlCommand($@"
            SELECT oi.OrderID, oi.BookID, b.Title, oi.Quantity, oi.PriceAtPurchase
            FROM OrderItemsBS oi
            JOIN BooksBS b ON b.BookID = oi.BookID
            WHERE oi.OrderID IN ({ids})
            ORDER BY oi.OrderItemID;", connection);
        using var itemReader = itemCommand.ExecuteReader();
        while (itemReader.Read())
        {
            var orderId = itemReader.GetInt32(itemReader.GetOrdinal("OrderID"));
            var quantity = itemReader.GetInt32(itemReader.GetOrdinal("Quantity"));
            var price = itemReader.GetDecimal(itemReader.GetOrdinal("PriceAtPurchase"));
            if (!itemsByOrder.TryGetValue(orderId, out var list))
                itemsByOrder[orderId] = list = new List<OrderItemDto>();
            list.Add(new OrderItemDto(
                itemReader.GetInt32(itemReader.GetOrdinal("BookID")),
                itemReader.GetString(itemReader.GetOrdinal("Title")),
                quantity, price, price * quantity));
        }

        orders = orders
            .Select(o => o with { Items = itemsByOrder.TryGetValue(o.OrderID, out var list) ? list : new List<OrderItemDto>() })
            .ToList();
    }

    return Results.Ok(orders);
})
.WithTags("Заказы")
.WithSummary("Все заказы магазина (только администратор и менеджер)")
.RequireAuthorization(policy => policy.RequireRole("Admin", "Manager"));

app.MapGet("/api/orders/my", (ClaimsPrincipal user, Db db) =>
{
    var userId = CurrentUserId(user);
    using var connection = db.Open();
    using var command = new SqlCommand(@"
        SELECT o.OrderID, o.UserID, u.UserLogin, u.UserFullName,
               o.OrderDate, o.Status, o.TotalAmount, o.CreatedAt
        FROM OrdersBS o
        JOIN UsersBS u ON u.UserID = o.UserID
        WHERE o.UserID = @uid
        ORDER BY o.OrderDate DESC, o.OrderID DESC;", connection);
    command.Parameters.AddWithValue("@uid", userId);

    var orders = new List<OrderDto>();
    using (var reader = command.ExecuteReader())
    {
        while (reader.Read())
        {
            orders.Add(new OrderDto(
                reader.GetInt32(reader.GetOrdinal("OrderID")),
                reader.GetInt32(reader.GetOrdinal("UserID")),
                reader.GetString(reader.GetOrdinal("UserLogin")),
                reader.GetString(reader.GetOrdinal("UserFullName")),
                reader.GetDateTime(reader.GetOrdinal("OrderDate")),
                reader.GetString(reader.GetOrdinal("Status")),
                reader.GetDecimal(reader.GetOrdinal("TotalAmount")),
                reader.GetDateTime(reader.GetOrdinal("CreatedAt")),
                Array.Empty<OrderItemDto>()));
        }
    }

    if (orders.Count > 0)
    {
        var ids = string.Join(",", orders.Select(o => o.OrderID));
        var itemsByOrder = new Dictionary<int, List<OrderItemDto>>();
        using var itemCommand = new SqlCommand($@"
            SELECT oi.OrderID, oi.BookID, b.Title, oi.Quantity, oi.PriceAtPurchase
            FROM OrderItemsBS oi
            JOIN BooksBS b ON b.BookID = oi.BookID
            WHERE oi.OrderID IN ({ids})
            ORDER BY oi.OrderItemID;", connection);
        using var itemReader = itemCommand.ExecuteReader();
        while (itemReader.Read())
        {
            var orderId = itemReader.GetInt32(itemReader.GetOrdinal("OrderID"));
            var quantity = itemReader.GetInt32(itemReader.GetOrdinal("Quantity"));
            var price = itemReader.GetDecimal(itemReader.GetOrdinal("PriceAtPurchase"));
            if (!itemsByOrder.TryGetValue(orderId, out var list))
                itemsByOrder[orderId] = list = new List<OrderItemDto>();
            list.Add(new OrderItemDto(
                itemReader.GetInt32(itemReader.GetOrdinal("BookID")),
                itemReader.GetString(itemReader.GetOrdinal("Title")),
                quantity, price, price * quantity));
        }

        orders = orders
            .Select(o => o with { Items = itemsByOrder.TryGetValue(o.OrderID, out var list) ? list : new List<OrderItemDto>() })
            .ToList();
    }

    return Results.Ok(orders);
})
.WithTags("Заказы")
.WithSummary("История заказов текущего пользователя")
.RequireAuthorization();

app.MapPost("/api/orders", (CreateOrderRequest request, ClaimsPrincipal user, Db db) =>
{
    if (request.Items is null || request.Items.Count == 0)
        return Results.BadRequest(new { message = "Заказ должен содержать хотя бы одну книгу." });

    if (request.Items.Any(i => i.Quantity <= 0))
        return Results.BadRequest(new { message = "Количество книг должно быть положительным." });

    var grouped = request.Items
        .GroupBy(i => i.BookID)
        .Select(g => new CreateOrderItem(g.Key, g.Sum(x => x.Quantity)))
        .ToList();

    var userId = CurrentUserId(user);

    using var connection = db.Open();
    using var transaction = connection.BeginTransaction(IsolationLevel.Serializable);
    try
    {
        var positions = new List<(int BookId, string Title, int Quantity, decimal Price)>();
        foreach (var item in grouped)
        {
            using var command = new SqlCommand(@"
                SELECT Title, Price, StockQuantity
                FROM BooksBS WITH (UPDLOCK, HOLDLOCK)
                WHERE BookID = @id;", connection, transaction);
            command.Parameters.AddWithValue("@id", item.BookID);

            using var reader = command.ExecuteReader();
            if (!reader.Read())
                throw new InvalidOperationException($"Книга с идентификатором {item.BookID} не найдена.");
            var title = reader.GetString(0);
            var price = reader.GetDecimal(1);
            var stock = reader.GetInt32(2);
            reader.Close();

            if (item.Quantity > stock)
                throw new InvalidOperationException($"Книги «{title}» недостаточно на складе: доступно {stock} шт.");
            positions.Add((item.BookID, title, item.Quantity, price));
        }

        var total = positions.Sum(p => p.Price * p.Quantity);

        int orderId;
        using (var command = new SqlCommand(@"
            INSERT INTO OrdersBS (UserID, OrderDate, Status, TotalAmount, CreatedAt)
            VALUES (@uid, GETDATE(), N'В обработке', @total, GETDATE());
            SELECT CAST(SCOPE_IDENTITY() AS INT);", connection, transaction))
        {
            command.Parameters.AddWithValue("@uid", userId);
            command.Parameters.AddWithValue("@total", total);
            orderId = Convert.ToInt32(command.ExecuteScalar());
        }

        foreach (var position in positions)
        {
            using (var command = new SqlCommand(@"
                INSERT INTO OrderItemsBS (OrderID, BookID, Quantity, PriceAtPurchase)
                VALUES (@oid, @bid, @q, @price);", connection, transaction))
            {
                command.Parameters.AddWithValue("@oid", orderId);
                command.Parameters.AddWithValue("@bid", position.BookId);
                command.Parameters.AddWithValue("@q", position.Quantity);
                command.Parameters.AddWithValue("@price", position.Price);
                command.ExecuteNonQuery();
            }

            using var stockCommand = new SqlCommand(@"
                UPDATE BooksBS SET StockQuantity = StockQuantity - @q
                WHERE BookID = @bid AND StockQuantity >= @q;", connection, transaction);
            stockCommand.Parameters.AddWithValue("@q", position.Quantity);
            stockCommand.Parameters.AddWithValue("@bid", position.BookId);
            if (stockCommand.ExecuteNonQuery() != 1)
                throw new InvalidOperationException("Не удалось списать остаток книги со склада.");
        }

        transaction.Commit();

        var items = positions
            .Select(p => new OrderItemDto(p.BookId, p.Title, p.Quantity, p.Price, p.Price * p.Quantity))
            .ToList();

        var order = new OrderDto(orderId, userId,
            user.Identity?.Name ?? string.Empty,
            user.FindFirstValue("fullName") ?? string.Empty,
            DateTime.Now, "В обработке", total, DateTime.Now, items);

        return Results.Created($"/api/orders/{orderId}", order);
    }
    catch (InvalidOperationException ex)
    {
        transaction.Rollback();
        return Results.BadRequest(new { message = ex.Message });
    }
    catch
    {
        transaction.Rollback();
        throw;
    }
})
.WithTags("Заказы")
.WithSummary("Оформление заказа с проверкой остатков и списанием со склада")
.RequireAuthorization(policy => policy.RequireRole("Admin", "Client"));

app.MapPut("/api/orders/{id:int}/status", (int id, StatusUpdateRequest request, Db db) =>
{
    var allowed = new[] { "В обработке", "Собирается", "Выполнен", "Отменён" };
    if (!allowed.Contains(request.Status))
        return Results.BadRequest(new { message = "Недопустимый статус заказа. Допустимо: " + string.Join(", ", allowed) });

    using var connection = db.Open();
    using var transaction = connection.BeginTransaction(IsolationLevel.Serializable);
    try
    {
        string currentStatus;
        using (var command = new SqlCommand(
            "SELECT Status FROM OrdersBS WITH (UPDLOCK, HOLDLOCK) WHERE OrderID = @id;", connection, transaction))
        {
            command.Parameters.AddWithValue("@id", id);
            var value = command.ExecuteScalar();
            if (value is null || value is DBNull)
            {
                transaction.Rollback();
                return Results.NotFound();
            }
            currentStatus = (string)value;
        }

        if (currentStatus == request.Status)
        {
            transaction.Commit();
            return Results.NoContent();
        }

        if (request.Status == "Отменён")
        {
            using var restore = new SqlCommand(@"
                UPDATE b
                SET b.StockQuantity = b.StockQuantity + oi.Quantity
                FROM BooksBS b
                JOIN OrderItemsBS oi ON oi.BookID = b.BookID
                WHERE oi.OrderID = @id;", connection, transaction);
            restore.Parameters.AddWithValue("@id", id);
            restore.ExecuteNonQuery();
        }
        else if (currentStatus == "Отменён")
        {
            using var deduct = new SqlCommand(@"
                UPDATE b
                SET b.StockQuantity = b.StockQuantity - oi.Quantity
                FROM BooksBS b
                JOIN OrderItemsBS oi ON oi.BookID = b.BookID
                WHERE oi.OrderID = @id;", connection, transaction);
            deduct.Parameters.AddWithValue("@id", id);
            deduct.ExecuteNonQuery();
        }

        using (var update = new SqlCommand(
            "UPDATE OrdersBS SET Status = @status WHERE OrderID = @id;", connection, transaction))
        {
            update.Parameters.AddWithValue("@status", request.Status);
            update.Parameters.AddWithValue("@id", id);
            update.ExecuteNonQuery();
        }

        transaction.Commit();
        return Results.NoContent();
    }
    catch
    {
        transaction.Rollback();
        throw;
    }
})
.WithTags("Заказы")
.WithSummary("Изменение статуса заказа (только администратор и менеджер)")
.RequireAuthorization(policy => policy.RequireRole("Admin", "Manager"));

// ---------- Отчёты ----------
app.MapGet("/api/reports/sales", (Db db, DateOnly? from, DateOnly? to) =>
{
    var dateFrom = (from ?? DateOnly.FromDateTime(DateTime.Today.AddDays(-30))).ToDateTime(TimeOnly.MinValue);
    var dateTo = (to ?? DateOnly.FromDateTime(DateTime.Today)).ToDateTime(TimeOnly.MaxValue);

    using var connection = db.Open();
    using var command = new SqlCommand(@"
        SELECT CAST(o.OrderDate AS DATE) AS Day,
               COUNT(DISTINCT o.OrderID) AS OrdersCount,
               ISNULL(SUM(oi.Quantity), 0) AS BooksSold,
               ISNULL(SUM(oi.Quantity * oi.PriceAtPurchase), 0) AS Revenue
        FROM OrdersBS o
        LEFT JOIN OrderItemsBS oi ON oi.OrderID = o.OrderID
        WHERE o.Status <> N'Отменён' AND o.OrderDate BETWEEN @from AND @to
        GROUP BY CAST(o.OrderDate AS DATE)
        ORDER BY Day;", connection);
    command.Parameters.AddWithValue("@from", dateFrom);
    command.Parameters.AddWithValue("@to", dateTo);

    var rows = new List<SalesReportRow>();
    using var reader = command.ExecuteReader();
    while (reader.Read())
    {
        rows.Add(new SalesReportRow(
            DateOnly.FromDateTime(reader.GetDateTime(0)),
            reader.GetInt32(1),
            reader.GetInt32(2),
            reader.GetDecimal(3)));
    }

    return Results.Ok(new
    {
        from = dateFrom,
        to = dateTo,
        totalOrders = rows.Sum(r => r.OrdersCount),
        totalBooks = rows.Sum(r => r.BooksSold),
        totalRevenue = rows.Sum(r => r.Revenue),
        rows
    });
})
.WithTags("Отчёты")
.WithSummary("Отчёт о продажах за период")
.RequireAuthorization(policy => policy.RequireRole("Admin", "Manager"));

app.MapGet("/api/reports/top-books", (Db db, int? take) =>
{
    var limit = Math.Clamp(take ?? 10, 1, 50);

    using var connection = db.Open();
    using var command = new SqlCommand($@"
        SELECT TOP ({limit}) b.BookID, b.Title,
               SUM(oi.Quantity) AS BooksSold,
               SUM(oi.Quantity * oi.PriceAtPurchase) AS Revenue
        FROM OrderItemsBS oi
        JOIN OrdersBS o ON o.OrderID = oi.OrderID
        JOIN BooksBS b ON b.BookID = oi.BookID
        WHERE o.Status <> N'Отменён'
        GROUP BY b.BookID, b.Title
        ORDER BY BooksSold DESC;", connection);

    var rows = new List<TopBookRow>();
    using var reader = command.ExecuteReader();
    while (reader.Read())
    {
        rows.Add(new TopBookRow(
            reader.GetInt32(0),
            reader.GetString(1),
            reader.GetInt32(2),
            reader.GetDecimal(3)));
    }

    return Results.Ok(rows);
})
.WithTags("Отчёты")
.WithSummary("Рейтинг самых продаваемых книг")
.RequireAuthorization(policy => policy.RequireRole("Admin", "Manager"));

app.MapGet("/api/health", () => Results.Ok(new { status = "ok", time = DateTime.Now }))
    .WithTags("Служебные")
    .WithSummary("Проверка работоспособности сервиса")
    .AllowAnonymous();

app.Run();
