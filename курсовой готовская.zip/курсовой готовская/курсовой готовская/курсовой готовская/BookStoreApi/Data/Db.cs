using Microsoft.Data.SqlClient;

namespace BookStoreApi.Data;

/// <summary>Провайдер подключения к учебной базе данных user83_db.</summary>
public sealed class Db
{
    private readonly string _connectionString;

    public Db(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("BookStoreDb")
            ?? throw new InvalidOperationException("Не задана строка подключения BookStoreDb.");
    }

    public SqlConnection Open()
    {
        var connection = new SqlConnection(_connectionString);
        connection.Open();
        return connection;
    }
}
