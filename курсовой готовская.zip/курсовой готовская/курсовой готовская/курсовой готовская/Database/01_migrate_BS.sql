/* ============================================================
   Миграция базы данных информационной системы «Книжный магазин»
   СУБД: Microsoft SQL Server
   База: user83_db
   Скрипт идемпотентный: повторный запуск не приводит к ошибкам
   ============================================================ */

/* ---------- 1. Роли: приводим справочник к трём используемым ролям ---------- */
UPDATE RolesBS SET RoleName = N'Клиент' WHERE RoleID = 2;
DELETE FROM RolesBS WHERE RoleID NOT IN (1, 2, 3);

/* ---------- 2. Расширение таблицы пользователей ---------- */
IF COL_LENGTH('dbo.UsersBS', 'Phone') IS NULL
    ALTER TABLE dbo.UsersBS ADD Phone NVARCHAR(30) NULL;
IF COL_LENGTH('dbo.UsersBS', 'Email') IS NULL
    ALTER TABLE dbo.UsersBS ADD Email NVARCHAR(100) NULL;
IF COL_LENGTH('dbo.UsersBS', 'Address') IS NULL
    ALTER TABLE dbo.UsersBS ADD Address NVARCHAR(250) NULL;

/* ---------- 3. Расширение таблицы книг ---------- */
IF COL_LENGTH('dbo.BooksBS', 'ISBN') IS NULL
    ALTER TABLE dbo.BooksBS ADD ISBN NVARCHAR(20) NULL;
IF COL_LENGTH('dbo.BooksBS', 'YearPublished') IS NULL
    ALTER TABLE dbo.BooksBS ADD YearPublished INT NULL;
IF COL_LENGTH('dbo.BooksBS', 'Description') IS NULL
    ALTER TABLE dbo.BooksBS ADD Description NVARCHAR(1000) NULL;

/* ---------- 4. Расширение справочника издательств (поставщиков) ---------- */
IF COL_LENGTH('dbo.PublishersBS', 'ContactPerson') IS NULL
    ALTER TABLE dbo.PublishersBS ADD ContactPerson NVARCHAR(150) NULL;
IF COL_LENGTH('dbo.PublishersBS', 'Phone') IS NULL
    ALTER TABLE dbo.PublishersBS ADD Phone NVARCHAR(30) NULL;
IF COL_LENGTH('dbo.PublishersBS', 'Email') IS NULL
    ALTER TABLE dbo.PublishersBS ADD Email NVARCHAR(100) NULL;
GO

/* ---------- 5. Заполнение демонстрационных данных ---------- */
UPDATE BooksBS SET ISBN = N'978-5-04-116312-1', YearPublished = 1869,
    Description = N'Роман-эпопея о России эпохи войн с Наполеоном, судьбах людей и поиске смысла жизни.'
    WHERE BookID = 1;
UPDATE BooksBS SET ISBN = N'978-5-17-118123-2', YearPublished = 1866,
    Description = N'Психологический роман о преступлении, совести и наказании.'
    WHERE BookID = 2;
UPDATE BooksBS SET ISBN = N'978-5-4461-0956-3', YearPublished = 2008,
    Description = N'Практическое руководство по написанию чистого, поддерживаемого кода.'
    WHERE BookID = 3;
UPDATE BooksBS SET Title = N'Гарри Поттер и философский камень', ISBN = N'978-5-389-07435-4', YearPublished = 1997,
    Description = N'Первая книга о юном волшебнике Гарри Поттере и школе Хогвартс.'
    WHERE BookID = 4;
UPDATE BooksBS SET ISBN = N'978-5-17-090820-5', YearPublished = 1967,
    Description = N'Мистический роман о добре и зле, любви и свободе.'
    WHERE BookID = 5;
UPDATE BooksBS SET ISBN = N'978-5-17-118456-0', YearPublished = 1949,
    Description = N'Антиутопия о тотальном контроле над личностью и свободой мысли.'
    WHERE BookID = 6;
UPDATE BooksBS SET ISBN = N'978-5-17-080053-0', YearPublished = 2011,
    Description = N'Книга о двух системах мышления и принятии решений.'
    WHERE BookID = 7;
UPDATE BooksBS SET ISBN = N'978-5-9614-6800-1', YearPublished = 1957,
    Description = N'Философский роман об объективизме, разуме и свободе личности.'
    WHERE BookID = 8;
UPDATE BooksBS SET ISBN = N'978-5-17-085444-0', YearPublished = 2011,
    Description = N'Биография основателя Apple Стива Джобса.'
    WHERE BookID = 9;
UPDATE BooksBS SET ISBN = N'978-5-04-116313-8', YearPublished = 1842,
    Description = N'Поэма о похождениях Чичикова и галерея образов русской жизни.'
    WHERE BookID = 10;
UPDATE BooksBS SET ISBN = N'978-5-389-06210-8', YearPublished = 1844,
    Description = N'Приключенческий роман о мести и справедливости.'
    WHERE BookID = 11;
UPDATE BooksBS SET ISBN = N'978-5-17-118457-7', YearPublished = 2005,
    Description = N'Постапокалиптическая фантастика о жизни в московском метро.'
    WHERE BookID = 12;
UPDATE BooksBS SET ISBN = N'978-5-389-07436-1', YearPublished = 1936,
    Description = N'Роман о дружбе, любви и судьбе поколения после Первой мировой войны.'
    WHERE BookID = 13;
UPDATE BooksBS SET ISBN = N'978-5-8459-2064-8', YearPublished = 1980,
    Description = N'Классический учебник по основам маркетинга.'
    WHERE BookID = 14;
UPDATE BooksBS SET ISBN = N'978-5-907114-45-7', YearPublished = 2009,
    Description = N'Фундаментальное руководство по разработке и анализу алгоритмов.'
    WHERE BookID = 15;

UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 411-68-86', Email = N'opt@eksmo.ru' WHERE PublisherID = 1;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 788-79-99', Email = N'opt@ast.ru' WHERE PublisherID = 2;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (812) 703-73-73', Email = N'opt@piter.com' WHERE PublisherID = 3;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (812) 324-56-40', Email = N'opt@azbooka.ru' WHERE PublisherID = 4;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 916-71-10', Email = N'opt@mif.ru' WHERE PublisherID = 5;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 980-53-54', Email = N'opt@alpinabook.ru' WHERE PublisherID = 6;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 783-33-21', Email = N'opt@rosman.ru' WHERE PublisherID = 7;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 795-05-50', Email = N'opt@drofa.ru' WHERE PublisherID = 8;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 789-30-40', Email = N'opt@prosv.ru' WHERE PublisherID = 9;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 744-00-12', Email = N'opt@urait.ru' WHERE PublisherID = 10;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 280-15-96', Email = N'opt@infra-m.ru' WHERE PublisherID = 11;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (495) 981-10-20', Email = N'opt@knorus.ru' WHERE PublisherID = 12;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (863) 261-89-50', Email = N'opt@phoenixrostov.ru' WHERE PublisherID = 13;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (383) 363-01-12', Email = N'opt@vector-book.ru' WHERE PublisherID = 14;
UPDATE PublishersBS SET ContactPerson = N'Отдел оптовых продаж', Phone = N'+7 (812) 327-93-70', Email = N'opt@soyuzkniga.ru' WHERE PublisherID = 15;

UPDATE UsersBS SET Phone = N'+7 (900) 000-00-01', Email = N'admin@bookstore.ru', Address = N'г. Ярославль, ул. Свободы, д. 10' WHERE UserID = 1;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-02', Email = N'manager@bookstore.ru', Address = N'г. Ярославль, ул. Свободы, д. 10' WHERE UserID = 2;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-03', Email = N'user1@bookstore.ru', Address = N'г. Ярославль, ул. Ленина, д. 15, кв. 3' WHERE UserID = 3;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-04', Email = N'user2@bookstore.ru', Address = N'г. Ярославль, пр-т Ленина, д. 22, кв. 17' WHERE UserID = 4;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-05', Email = N'user3@bookstore.ru', Address = N'г. Ярославль, ул. Собинова, д. 5, кв. 8' WHERE UserID = 5;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-06', Email = N'user4@bookstore.ru', Address = N'г. Ярославль, ул. Пушкина, д. 8, кв. 12' WHERE UserID = 6;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-07', Email = N'user5@bookstore.ru', Address = N'г. Ярославль, ул. Кирова, д. 3, кв. 5' WHERE UserID = 7;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-08', Email = N'user6@bookstore.ru', Address = N'г. Ярославль, ул. Волкова, д. 14, кв. 9' WHERE UserID = 8;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-09', Email = N'user7@bookstore.ru', Address = N'г. Ярославль, ул. Угличская, д. 21, кв. 4' WHERE UserID = 9;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-10', Email = N'user8@bookstore.ru', Address = N'г. Ярославль, ул. Рыбинская, д. 7, кв. 11' WHERE UserID = 10;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-11', Email = N'user9@bookstore.ru', Address = N'г. Ярославль, ул. Трефолева, д. 18, кв. 2' WHERE UserID = 11;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-12', Email = N'user10@bookstore.ru', Address = N'г. Ярославль, ул. Чайковского, д. 30, кв. 6' WHERE UserID = 12;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-13', Email = N'user11@bookstore.ru', Address = N'г. Ярославль, ул. Свердлова, д. 12, кв. 14' WHERE UserID = 13;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-14', Email = N'user12@bookstore.ru', Address = N'г. Ярославль, ул. Городской вал, д. 9, кв. 7' WHERE UserID = 14;
UPDATE UsersBS SET Phone = N'+7 (900) 000-00-15', Email = N'user13@bookstore.ru', Address = N'г. Ярославль, ул. Комсомольская, д. 4, кв. 10' WHERE UserID = 15;
GO

/* ---------- 6. Статусы заказов и дата создания ---------- */
UPDATE OrdersBS SET Status = N'Отменён' WHERE Status = N'Отменен';
UPDATE OrdersBS SET CreatedAt = ISNULL(CreatedAt, OrderDate);
UPDATE OrdersBS SET CreatedAt = GETDATE() WHERE OrderID = 28;

/* ---------- 7. Ограничения целостности ---------- */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_OrdersBS_Status')
    ALTER TABLE dbo.OrdersBS WITH NOCHECK ADD CONSTRAINT CK_OrdersBS_Status
        CHECK (Status IN (N'В обработке', N'Собирается', N'Выполнен', N'Отменён'));
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_OrdersBS_TotalAmount')
    ALTER TABLE dbo.OrdersBS WITH NOCHECK ADD CONSTRAINT CK_OrdersBS_TotalAmount CHECK (TotalAmount >= 0);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_BooksBS_YearPublished')
    ALTER TABLE dbo.BooksBS WITH NOCHECK ADD CONSTRAINT CK_BooksBS_YearPublished
        CHECK (YearPublished IS NULL OR (YearPublished BETWEEN 1500 AND YEAR(GETDATE())));
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_UsersBS_FailedAttempts')
    ALTER TABLE dbo.UsersBS WITH NOCHECK ADD CONSTRAINT CK_UsersBS_FailedAttempts CHECK (FailedAttempts >= 0);

IF NOT EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'UQ_CartItemsBS_User_Book')
    ALTER TABLE dbo.CartItemsBS ADD CONSTRAINT UQ_CartItemsBS_User_Book UNIQUE (UserID, BookID);
IF NOT EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'UQ_OrderItemsBS_Order_Book')
    ALTER TABLE dbo.OrderItemsBS ADD CONSTRAINT UQ_OrderItemsBS_Order_Book UNIQUE (OrderID, BookID);
IF NOT EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'UQ_PublishersBS_Name')
    ALTER TABLE dbo.PublishersBS ADD CONSTRAINT UQ_PublishersBS_Name UNIQUE (PublisherName);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UQ_BooksBS_ISBN' AND object_id = OBJECT_ID('dbo.BooksBS'))
    CREATE UNIQUE INDEX UQ_BooksBS_ISBN ON dbo.BooksBS(ISBN) WHERE ISBN IS NOT NULL;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UQ_UsersBS_Email' AND object_id = OBJECT_ID('dbo.UsersBS'))
    CREATE UNIQUE INDEX UQ_UsersBS_Email ON dbo.UsersBS(Email) WHERE Email IS NOT NULL;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_BooksBS_Title' AND object_id = OBJECT_ID('dbo.BooksBS'))
    CREATE INDEX IX_BooksBS_Title ON dbo.BooksBS(Title);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_BooksBS_Author' AND object_id = OBJECT_ID('dbo.BooksBS'))
    CREATE INDEX IX_BooksBS_Author ON dbo.BooksBS(Author);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OrdersBS_UserID' AND object_id = OBJECT_ID('dbo.OrdersBS'))
    CREATE INDEX IX_OrdersBS_UserID ON dbo.OrdersBS(UserID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OrdersBS_OrderDate' AND object_id = OBJECT_ID('dbo.OrdersBS'))
    CREATE INDEX IX_OrdersBS_OrderDate ON dbo.OrdersBS(OrderDate);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OrderItemsBS_OrderID' AND object_id = OBJECT_ID('dbo.OrderItemsBS'))
    CREATE INDEX IX_OrderItemsBS_OrderID ON dbo.OrderItemsBS(OrderID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CartItemsBS_UserID' AND object_id = OBJECT_ID('dbo.CartItemsBS'))
    CREATE INDEX IX_CartItemsBS_UserID ON dbo.CartItemsBS(UserID);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_UsersBS_RoleID' AND object_id = OBJECT_ID('dbo.UsersBS'))
    CREATE INDEX IX_UsersBS_RoleID ON dbo.UsersBS(RoleID);

/* ---------- 8. Представление для каталога ---------- */
IF OBJECT_ID('dbo.vwBooksBS', 'V') IS NOT NULL DROP VIEW dbo.vwBooksBS;
GO
CREATE VIEW dbo.vwBooksBS AS
SELECT b.BookID, b.Title, b.Author, b.PublisherID, p.PublisherName, p.ContactPerson,
       p.Phone AS PublisherPhone, b.Genre, b.ISBN, b.YearPublished, b.Price,
       b.StockQuantity, b.CoverImagePath, b.Description
FROM dbo.BooksBS b
JOIN dbo.PublishersBS p ON p.PublisherID = b.PublisherID;
GO

/* ---------- 9. Проверка результата ---------- */
SELECT N'RolesBS' AS TableName, COUNT(*) AS RowCount FROM dbo.RolesBS
UNION ALL SELECT N'UsersBS', COUNT(*) FROM dbo.UsersBS
UNION ALL SELECT N'PublishersBS', COUNT(*) FROM dbo.PublishersBS
UNION ALL SELECT N'BooksBS', COUNT(*) FROM dbo.BooksBS
UNION ALL SELECT N'OrdersBS', COUNT(*) FROM dbo.OrdersBS
UNION ALL SELECT N'OrderItemsBS', COUNT(*) FROM dbo.OrderItemsBS
UNION ALL SELECT N'CartItemsBS', COUNT(*) FROM dbo.CartItemsBS;
